https://blog.csdn.net/windy1001/article/details/81486091

#### 安装依赖
```
yum install  -y zlib*
yum install  -y libffi-devel
```

#### 下架安装
```
wget https://www.python.org/ftp/python/3.7.3/Python-3.7.3.tgz
tar -zxvf Python-3.7.3.tgz
cd Python-3.7.3
./configure
make && make install
```
至此，Python3.7已经安装完成。

如果已经安装了Python2.x的同学，需要重新做一下软链，具体操作如下：
```
cd /usr/bin/
mv /usr/bin/python /usr/bin/python.2.bak
ln -s  /usr/local/bin/python3 /usr/bin/python
```
这时候python  -V就可以看到是变成3.7的版本了
#### 查看版本
```
python --version
```