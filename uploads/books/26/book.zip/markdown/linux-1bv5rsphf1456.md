文件句柄限制


## 全局限制
```
cat /proc/sys/fs/file-nr
```
执行 输出 ，分别为：
```
1664	0	13109166
```

1. 已经分配的文件句柄数，
2. 已经分配但没有使用的文件句柄数，
3. 最大文件句柄数。

但在kernel 2.6版本中第二项的值总为0，这并不是一个错误，它实际上意味着已经分配的文件描述符无一浪费的都已经被使用了 。


我们可以把这个数值改大些，用 root 权限修改 `/etc/sysctl.conf` 文件:
```
fs.file-max = 1000000
net.ipv4.ip_conntrack_max = 1000000
net.ipv4.netfilter.ip_conntrack_max = 1000000
```