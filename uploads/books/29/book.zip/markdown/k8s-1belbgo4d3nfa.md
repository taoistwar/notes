参考：
+ https://blog.csdn.net/qq_25611295/article/details/85268581
+ https://www.cnblogs.com/dingbin/p/9754993.html
helm安装
+ https://blog.csdn.net/bbwangj/article/details/82863042
+ https://www.cnblogs.com/jcici/p/11126581.html


简介
+ 转发不同的域名请求到集群中不同的服务上
+ Ingress 就是从 Kubernetes 集群外访问集群的入口，将用户的URL请求转发到不同的 Service 上。

## 安装
```
helm install --namespace kube-system --name nginx-ingress \
  --set rbac.create=true \
  --set controller.hostNetwork=true \
  --set controller.dnsPolicy=ClusterFirstWithHostNet \
  --set controller.kind=DaemonSet \
  --set controller.stats.enabled=true \
  --set controller.metrics.enabled=true \
  stable/nginx-ingress
```

#### helm 安装
+ hostNetwork方式

```
helm install --namespace kube-system --name nginx-ingress \
  --set rbac.create=true \
  --set controller.hostNetwork=true \
  --set controller.dnsPolicy=ClusterFirstWithHostNet \
  --set controller.kind=DaemonSet \
  --set controller.stats.enabled=true \
  --set controller.metrics.enabled=true \
  stable/nginx-ingress
```

+ externalIPs方式
```
helm install --name nginx-ingress --set "rbac.create=true,controller.service.externalIPs[0]=10.141.179.103" stable/nginx-ingress
```

#### 安装Ingress Controller


```
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/master/deploy/static/mandatory.yaml
```

```
 kubectl edit pod nginx-ingress-controller-7995bd9c47-6g8xd  -n ingress-nginx
```

## 使用Ingress
#### 创建测试服务
```
apiVersion: v1
kind: Service
metadata:
  name: myapp-ding
  namespace: default
spec:
  selector:
    app: myapp
    release: ding
  ports:
    - name: http
      port: 80
      targetPort: 80
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp-ding
  namespace: default
spec:
  replicas: 3
  selector:
    matchLabels:
      app: myapp
      release: ding
  template:
    metadata:
      labels:
        app: myapp
        release: ding
    spec:
      containers:
        - name: myapp-ding
          image: ikubernetes/myapp:v2
          ports:
            - name: http
              containerPort: 80
```
#### 创建Ingress规则
```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-ding
  namespace: default
  annotations:
    kubernetes.io/ingress.class: "nginx"
spec:
  rules:
  - host: socsight.com
    http:
      paths:
      - path: /
        backend:
          serviceName: web-mindoc
          servicePort: 80
```