## 创建用户
#### token方式登录账号
##### 创建账号并授权
+ 创建账号：
创建用于登录dashborad的serviceaccount账号
```
kubectl create serviceaccount dashboard-admin -n kube-system
```

+ 添加角色：
创建一个clusterrolebinding，将名称为cluster-admin的clusterrole绑定到我们刚刚从的serviceaccount上，名称空间和sa使用:作为间隔
```
kubectl create clusterrolebinding dashboard-cluster-admin --clusterrole=cluster-admin --serviceaccount=kube-system:dashboard-admin
```

##### 查看Secret和token
+ 创建完成ServiceAccount后，系统会自动创建一个secret。名称以serviceaccount(即，dashboard-admin)名称开头
```
kubectl get secret -n kube-system | grep dashboard-admin
```

+ 查看Secret：
token也就是在dashboard页面登录时使用的
```
kubectl describe secret `kubectl get secret -n kube-system | grep dashboard-admin|awk '{print $1}'` -n kube-system
```