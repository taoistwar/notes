注：使用的是基于VirtualBox的双网卡（NAT网络、Host-only）虚拟机(CentOS 7)环境。

官网：https://github.com/kubernetes/dashboard

参考：
+ 安装 https://www.jianshu.com/p/c6d560d12d50
+ 使用 https://www.cnblogs.com/panwenbin-logs/p/10052554.html
+ 理论 https://www.imooc.com/article/49019

## 安装
查看最新Relase版本：
https://github.com/kubernetes/dashboard/releases

即，v1.10.1
#### 获取配置文件
`alias ksys='kubectl -n kube-system'`
下载配置文件：
```
wget https://raw.githubusercontent.com/kubernetes/dashboard/v1.10.1/src/deploy/recommended/kubernetes-dashboard.yaml
```

#### 去除Secret
我们需要重新生成secret，并且将该配置文件中创建secret的配置文件信息去掉
```
# ------------------- Dashboard Secret ------------------- #

#apiVersion: v1
#kind: Secret
#metadata:
#  labels:
#    k8s-app: kubernetes-dashboard
#  name: kubernetes-dashboard-certs
#  namespace: kube-system
#type: Opaque

#---
```
注： 前边加 `#` 注释掉。

#### 修改镜像文件
如果被墙了
+ 设置docker仓库
+ 修改镜像
```
vi kubernetes-dashboard.yaml
```
带`image:`行修改为：
```
image: mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1
```
#### 修改为NodePort
找到行：
```
kind: Service
```
将下边
```
kubectl -n kube-system edit svc kubernetes-dashboard
```
将 `spec.type` 改为 `NodePort`
![](http://socsight.com/uploads/201908/k8s/attach_15bc3590a9686b13.png)
注：
+ `nodePort: 31234` 表示使用固定的端口 `31234`，如果没有指定k8s会自动生成一个端口。


#### 生成证书
生成证书
```
openssl genrsa -out dashboard.key 2048
openssl req -new -out dashboard.csr -key dashboard.key -subj '/CN=10.141.179.103'
openssl x509 -req -in dashboard.csr -signkey dashboard.key -out dashboard.crt
openssl x509 -in dashboard.crt -text -noout
```
创建Secret
```
kubectl -n kube-system create secret generic kubernetes-dashboard-certs --from-file=dashboard.key --from-file=dashboard.crt
```
查看Secret
```
kubectl -n kube-system describe secret kubernetes-dashboard-certs
```

注：
+ 10.141.179.103 是节点的IP，通过此IP访问dashboard（即`https://10.141.179.103:xxxxx`）

#### 安装集群
```
kubectl apply -f kubernetes-dashboard.yaml
```


## 创建用户
#### token方式登录用户
+ 创建用于登录dashborad的serviceaccount账号
```
kubectl create serviceaccount dashboard-admin -n kube-system
```

+ 创建一个clusterrolebingding，将名称为cluster-admin的clusterrole绑定到我们刚刚从的serviceaccount上，名称空间和sa使用:作为间隔
```
kubectl create clusterrolebinding dashboard-cluster-admin --clusterrole=cluster-admin --serviceaccount=kube-system:dashboard-admin
```

+ 创建完成后系统会自动创建一个secret，名称以serviceaccount(即，dashboard-admin)名称开头
```
kubectl get secret -n kube-system | grep dashboard-admin
```

+ 使用describe查看该secret的详细信息，主要是token一段
```
kubectl describe secret `kubectl get secret -n kube-system | grep dashboard-admin|awk '{print $1}'` -n kube-system
```