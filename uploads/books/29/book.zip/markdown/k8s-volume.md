## 本地数据卷
作用
+ Pod中文件共享
+ 宿主机中文件共享


cephfs
gitRepo
secret
persistentVolumeClaim
downwardAPI
azureFileVolume
#### emptyDir
如果 Pod 设置了 emptyDir 类型 Volume， Pod 被分配到 Node 上时候， 会创建emptyDir， 只要 Pod 运行在 Node 上， emptyDir 都会存在（ 容器挂掉不会导致emptyDir 丢失数据） 。

但是如果 Pod 从 Node 上被删除（ Pod 被删除， 或者 Pod 发生迁移） ， emptyDir 也会被删除， 并且永久丢失。

#### hostPath
hostPath 允许挂载 Node 上的文件系统到 Pod 里面去。 如果 Pod 需要使用 Node 上的文件， 可以使用 hostPath

## 网络数据卷

#### NFS
Network File System， 网络文件系统。

作用：
+ 通过网络，让不同的机器、不同的操作系统可以共享彼此的文件。
+ NFS服务器可以让PC将网络中的NFS服务器共享的目录挂载到本地端的文件系统中，而在本地端的系统中来看，那个远程主机的目录就好像是自己的一个磁盘分区一样，在使用上相当便利；

```
yum install nfs-utils rpcbind net-tools lsof
systemctl status rpcbind
systemctl restart rpcbind
systemctl enable rpcbind
systemctl status nfs
systemctl restart nfs
systemctl enable nfs
```

https://www.cnblogs.com/me80/p/7464125.html
#### GlusterFS
分布式文件系统， 广泛应用于各类非结构化数据的存储与共享环境，例如流媒体、数据分析以及其他数据和带宽密集型业务。

优点：
+ 无元数据节点性能瓶颈
+ 良好的可扩展性
+ 高可用
+ 高性能
+ 存储池类型丰富

缺点：
+ 小文件性能较差
+ 遍历目录下文件耗时
+ 扩容、缩容时影响的服务器较多

#### RBD
Ceph Block Device
http://docs.ceph.org.cn/

#### iSCSI
#### Flocker

#### gcePersistentDisk
Google Container Engine
#### awsElasticBlockStore
AWS的Amazon EC2


## PV 和 PVC
PV
+ 预先定义的一些存储

PVC
+ 自动从选择合适的PV，屏蔽具体存储实现。

#### hostPath PV

```
apiVersion: v1
kind: PersistentVolume
metadata:
  name: mysql-pv

spec:
  accessModes:
  - ReadWriteOnce
  capacity:
    storage: 8Gi
  persistentVolumeReclaimPolicy: Retain
  hostPath:
    path: /test/mysql
```