https://www.cnblogs.com/panwenbin-logs/p/9895953.html

##### onfigMap传递环境变量

##### 使用secret传递环境变量

##### 定义pod postStart或preStop,即容器创建后和容器中止前需要做的操作

##### 以exec方式对pod进行存活性探测
##### 使用httpget方式对pod进行就绪性探测
#####