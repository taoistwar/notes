将集群外部流量导入到集群内的方式：
+ Kubernets proxy模式
+ NodePort
+ LoadBalancer
+ Ingress


参考：
+ https://www.cnblogs.com/devilwind/p/8891636.html
## Proxy模式
```
kubectl proxy --port=8080
```

缺点：
+ 通常用于调试

## NodePort
在所有节点（Node）上开放一个特定端口，任何发送到该端口的流量都被转发到对应服务。

缺点：
+ 每个端口只能是一种服务
+ 端口范围只能是 30000-32767
+ 需要应对Node的IP发生变化

## LoadBalancer
LoadBalancer 服务是暴露服务到 internet 的标准方式。在 GKE 上，这种方式会启动一个 Network Load Balancer[2]，它将给你一个单独的 IP 地址，转发所有流量到你的服务。

缺点：
+ 需要IP，外网IP是要花钱嘀

## Ingress
它允许你基于路径或者子域名来路由流量到后端服务。

例如，你可以将任何发往域名 foo.yourdomain.com 的流量转到 foo 服务，将路径 yourdomain.com/bar/path 的流量转到 bar 服务。