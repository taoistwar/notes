### 操作系统
#### 设置主机名
加入node时需要使用
```
10.0.2.15 master
10.0.2.4  node-01
```

#### 关闭swap
```
swapoff -a
yes | cp /etc/fstab /etc/fstab_bak
cat /etc/fstab_bak |grep -v swap > /etc/fstab
```

#### 防火墙
要么关闭、要么开放端口
+ 禁用防火墙
```
systemctl stop firewalld
systemctl disable firewalld
```
+ 开放端口
```
systemctl enable firewalld
systemctl start firewalld
firewall-cmd --add-masquerade --permanent
firewall-cmd --add-port=10250/tcp --permanent
firewall-cmd --add-port=8472/udp --permanent
firewall-cmd --add-port=6443/tcp --permanent
firewall-cmd --reload
```

#### iptables
##### 设置iptables的FOWARD链为ACCEPT

+ 设置
```
iptables -P FORWARD ACCEPT
iptables-save > /etc/sysconfig/iptables
```
+ 查看
确认一下iptables filter表中FOWARD链的默认策略(pllicy)为ACCEPT。
```
iptables -nvL
```

##### netfilter
+ 修改iptables相关参数
+ RHEL / CentOS 7上的一些用户报告了由于iptables被绕过而导致流量路由不正确的问题。

```
cat <<EOF >  /etc/sysctl.d/k8s.conf
vm.swappiness = 0
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward = 1
EOF

modprobe br_netfilter
sysctl -p /etc/sysctl.d/k8s.conf

yum install ipset ipvsadm -y
```

#### Selinux
不支持，只能关闭
```
setenforce 0
sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
```

#### 加载ipvs相关模块
由于ipvs已经加入到了内核的主干，所以为kube-proxy开启ipvs的前提需要加载以下的内核模块：

`ip_vs`, `ip_vs_rr`, `ip_vs_wrr`, `ip_vs_sh`, `nf_conntrack_ipv4`

```
cat > /etc/sysconfig/modules/ipvs.modules <<EOF
#!/bin/bash
modprobe -- ip_vs
modprobe -- ip_vs_rr
modprobe -- ip_vs_wrr
modprobe -- ip_vs_sh
modprobe -- nf_conntrack_ipv4
EOF
chmod 755 /etc/sysconfig/modules/ipvs.modules
bash /etc/sysconfig/modules/ipvs.modules
```
查看是否已经正确加载所需的内核模块
```
lsmod | grep -e ip_vs -e nf_conntrack_ipv4
```