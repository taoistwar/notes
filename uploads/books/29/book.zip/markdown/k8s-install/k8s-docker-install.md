### Docker
#### 添加仓库
```
sudo yum install -y yum-utils device-mapper-persistent-data lvm2

sudo yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

注：
仓库地址：
+ 阿里云： 速度快
http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
+ 官方： 更安全（？）
https://download.docker.com/linux/centos/docker-ce.repo

#### 查看最新docker版本
```
yum list docker-ce.x86_64  --showduplicates |sort -r
```

#### 安装docker
```
yum install -y --setopt=obsoletes=0 docker-ce-18.09.8-3.el7
yum install -y --setopt=obsoletes=0 docker-ce-19.03.8-3.el7
```
注：Kubernetes V1.15.2支持的最新docker是18.09。
但一不小心升级docker-ce到19.03.1，没出问题。


#### 修改docker cgroup driver为systemd，设置阿里云仓库
对于使用systemd作为init system的Linux的发行版，使用systemd作为docker的cgroup driver可以确保服务器节点在资源紧张的情况更加稳定。

+ 创建目录 `mkdir -p /etc/docker/`
+ 创建或修改/etc/docker/daemon.json：
```
cat > /etc/docker/daemon.json <<EOF
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "registry-mirrors": [
    "https://khec465u.mirror.aliyuncs.com"
  ]
}
EOF
```
错误
`E437: terminal capability "cm" required`
这个错误一般是环境变量TERM没有配置或者配置错误所致。
解决办法：
执行`export TERM=xterm`；
或者将export TERM=xterm 添加至profile文件中即可。

+ 重启docker：
```
mkdir -p /etc/systemd/system/docker.service.d
systemctl enable docker.service
systemctl daemon-reload
systemctl restart docker
```
+ 检查是否成功：
```
docker info | grep Cgroup
```
返回`Cgroup Driver: systemd`，表示修改为systemd。

#### 运行Docker Hello world
```
docker run hello-world
```