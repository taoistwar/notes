## 配置REPO
```
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF
```
## 安装kubeadm
```
yum install -y kubeadm --disableexcludes=kubernetes
```

## 安装配置Kubelet
设置开始自动启动kubelet，查看kubelet状态。
```
yum install -y kubelet --disableexcludes=kubernetes
systemctl enable --now kubelet
systemctl status kubelet
```

+ 配置swap。无视swap on的错误。kubernetes不推荐使用虚拟内存，不使用虚拟内存时需要足够多的物理内存。所以作为学习用时还是使用虚拟内存性能好些。好吧，屌丝专用！
```
cat <<EOF > /etc/sysconfig/kubelet
KUBELET_EXTRA_ARGS=--fail-swap-on=false
EOF
```

https://www.cnblogs.com/iiiiher/p/7879587.html