## 网络
NAT网络 + Host only

参考
+ [配置网络](https://www.linuxidc.com/Linux/2018-04/151924.htm "配置网络")