## 发布一个nginx deployment，进行检证。
##### 发布
```
kubectl create deployment nginx --image=nginx
```
##### 查看deployments
```
kubectl get deployments
```
+ READY=0 异常
![](http://socsight.com/uploads/201908/k8s/attach_15ba5f883a02716a.png)
  
+ Ready=1 正常
![](http://socsight.com/uploads/201908/k8s/attach_15ba648e65c7656f.png)

##### 查看pods
```
kubectl get pods -o wide
```
##### 查看pods的结果
```
NAME                     READY   STATUS    RESTARTS   AGE   IP                NODE     NOMINATED NODE   READINESS GATES
nginx-554b9c67f9-trvqx   1/1     Running   0          81s   192.168.150.196   k8s115   <none>           <none>
```
##### 用curl访问nginx应用（IP是查看pods的结果的IP值）
```
curl 192.168.40.196
```