## Master加入到Node

```
kubectl taint nodes --all node-role.kubernetes.io/master-
```
##  Worker加入到Node
如果忘记，在Master上使用命令获取，然后在worker节点上执行。
```
kubeadm token create --print-join-command
```


Worker节点执行命令：
```
kubeadm join 10.0.2.15:6443 \
	--token a9nzv5.73z3iviwy5wr7gkw \
	--discovery-token-ca-cert-hash sha256:a1dc41a1d1c0a098d372333e16f5f255d15546bc211ca544bdf6f300c0fbe9f8 \
	--ignore-preflight-errors=SystemVerification
```