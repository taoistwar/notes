## 安装方式
+ kubeadm 官方推荐的集群搭建方式
+ [Rancher](https://www.cnrancher.com/docs/rancher/v2.x/cn/overview/ "Rancher")
+ 二进制安装 手动
+ Minikube 单机

## VirtualBox搭建虚拟机集群
[传送门](http://socsight.com/docs/k8s/k8s-virtualbox "VirtualBox搭建虚拟机集群")

## 安装K8s
参考

+ [官方文档](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/ "官方文档")
+ https://blog.csdn.net/networken/article/details/84991940
+ https://blog.csdn.net/engchina/article/details/93119626
+ https://www.kubernetes.org.cn/5551.html
+ https://www.kuboard.cn/install/install-k8s.html

### Master 安装
#### 操作系统预先配置
[传送门](http://socsight.com/docs/k8s/k8s-preset "操作系统预先配置")
#### Docker安装配置
[传送门](http://socsight.com/docs/k8s/k8s-docker-install "Docker安装配置")
#### Kubeadm初始化集群，配置kubectl
[传送门](http://socsight.com/docs/k8s/k8s-1beh197gsru2p "Kubeadm初始化集群，配置kubectl")
#### 安装配置kubelet
[传送门](http://socsight.com/docs/k8s/k8s-1beh33bj0q9gt "安装配置kubelet")

### Worker 安装
#### 操作系统预先配置
[传送门](http://socsight.com/docs/k8s/k8s-preset "操作系统预先配置")
#### Docker安装配置
[传送门](http://socsight.com/docs/k8s/k8s-docker-install "Docker安装配置")
#### 安装配置kubelet
[传送门](http://socsight.com/docs/k8s/k8s-1beh33bj0q9gt "安装配置kubelet")

#### 添加Node
[传送门](http://socsight.com/docs/k8s/k8s-1beh3fgea0ka1 "添加Node")

## kubectl管理工具
#### 查看nodes
```
kubectl get nodes
```
+ 错误结果
![](http://socsight.com/uploads/201908/k8s/attach_15ba5e1aa9174872.png)

查看错误日志
`journalctl -f -u kubelet`
发现`NetworkPluginNotReady`
因为初始化集群后，忘记重装网络插件了。
+ 最终结果
![](http://socsight.com/uploads/201908/k8s/attach_15ba5f5fd0e8d281.png)

#### 查看所用pods
```
kubectl get pods --all-namespaces
```
等待所有状态为 `Running`
![](http://socsight.com/uploads/201908/k8s/attach_15ba5f66c6f957a2.png)


## 验证集群
[传送门](http://socsight.com/docs/k8s/k8s-1bejdrb0frg8u "传送门")


## 高可用安装

+ https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/high-availability/
+ https://www.kuboard.cn/install/install-kubernetes.html