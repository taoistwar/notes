Master节点上，多了两个组件：kubeadm、kubectl

## kubeadm
安装部署集群

## kubectl
管理配置集群