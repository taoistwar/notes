## 为k8s提供网络的插件有很多，主流：
+ flannel
+ calico

只须二选一。

### 安装`Calico`网络插件
```
kubectl apply -f https://docs.projectcalico.org/manifests/calico.yaml
```
[calico.yaml文件内容](http://socsight.com/docs/k8s/k8s-1beh1lr63lgag "calico.yaml文件内容")

参考：
https://docs.projectcalico.org/getting-started/kubernetes/quickstart
### 安装flannel