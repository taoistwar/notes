### pod错误
+ 查看pods状态
`kubectl get pods`
![](http://socsight.com/uploads/201908/k8s/attach_15ba5fa948916c80.png)

+ `ImagePullBackOff` 表示正在后台下载镜像，查错……

+ 查看pod日志
`kubectl describe pod nginx-554b9c67f9-nzn6s`
错误信息 `Failed to pull image "nginx"`

+ Node上直接使用docker下载镜像
`docker pull nginx`
错误信息 `dial tcp 104.18.121.25:443: i/o timeout`，被墙了。
解决方法：在安装docker时，添加阿里云仓库。

## node错误
查看错误日志
`journalctl -f -u kubelet`
发现`NetworkPluginNotReady`