service工作模式:userspace(1.1版本之前)、iptables(1.10版本之前)和ipvs(1.11版本之后)

#### 端口
+ port: 服务的端口
+ targetPort: Pod的端口
+ nodePort: 宿主机的端口

## Servcie 定义文件
```
apiVersion: v1
kind: Service
matadata:
  name: string
  namespace: string
  labels:
  - name: string
  annotations:
  - name: string
spec:
  selector: []
  type: string
  clusterIP: string
  sessionAffinity: string
  ports:
  - name: string
    protocol: string
    port: int
    targetPort: int
    nodePort: int
  status:
    loadBalancer:
      ingress:
        ip: string
        hostname: string
```