## 命令方式

### Pod

#### 查看Pod
```
 kubectl get pod -w
```
-w是一直等待的意思


### deployment
#### 创建deployment
```
kubectl run nginx-deploy --image=nginx:1.14-alpine --port=80 --replicas=1 --dry-run=true
```
说明：
+ nginx-deploy表示deployment的名称
+ --image表示镜像的地址
+ --port表示pod暴露的端口
+ --replicas表示副本的个数
+ --dry-run表示测试，不真正执行命令

```
kubectl run nginx-deploy --image=nginx:1.14-alpine --port=80 --replicas=1
```

#### 查看deployment列表
+ 简要信息
```
 kubectl get deployment
```
+ 更详细的显示信息
```
kubectl get pod -o wide
```

集群内访问
```
curl -I 10.244.2.2
```
#### 查看deployment明细
```
kubectl describe deployment nginx
```

### service
#### 创建Service
```
kubectl expose deployment nginx-deploy --name=nginx   --port=80 --target-port=80 --type=NodePort
```

+ 使用kubectl expose 可以创建一个service ，可以使用 kubectl expose -h命令查看命令帮助

#### 查看Service列表
```
kubectl get svc -o wide
```
注： NodePort类型的Service，会在每个Node上开启一个端口。可以从集群外部访问服务。

#### 查看Service明细
```
kubectl describe svc nginx
```

### 伸缩（扩容和缩减）
```
kubectl scale --replicas=5 deployment nginx-deploy
```
对名称为nginx-deploy类型为deployment的对象进行扩容，复本设置为5个。

### 升级与回滚
#### 滚动升级
```
kubectl set image deployment nginx-deploy nginx-deploy=nginx:1.15-alpine --record
```

#### 版本回滚
````
kubectl rollout undo deployment nginx-deploy
```
--to-revision 参数可以指定回退的版本


### configmap
#### 创建configmap
```
kubectl create configmap special-config --from-literal=special.how=very --from-literal=sepcial.type=charm
```

#### 查看cnofigmap
```
kubectl get configmap special-config -o go-template='{{.data}}'
```

### node label
```
kubectl label node k8s-node01 disk=ssd
```
对集群中的一个节点打上标签
### Secret

```
apiVersion: v1
kind: Secret
metadata:
  name: mysecret
type: Opaque
data:
  password: MTIzNDU2Cg==
  username: YWRtaW4K
```
这里的环境变量的值需要使用base64加密，

例如：echo "admin"|base64[加密] ， echo "YWRtaW4K"|base64 -d [解密]