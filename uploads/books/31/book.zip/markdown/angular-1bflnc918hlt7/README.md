## 预置安装
#### Node安装

参考：
+ [安装Node](http://socsight.com/docs/angular/angular-node "安装Node")


## 安装Angular