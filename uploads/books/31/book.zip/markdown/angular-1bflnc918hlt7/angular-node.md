官网：https://nodejs.org/en/

#### Node安装
```
nvmw install 10.16.3
```

参考:
+ [nvmw安装](/docs/angular/angular-nvmw "nvmw安装")