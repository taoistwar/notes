## *ngFor
```
<h2>My Heroes</h2>
<ul class="heroes">
  <li *ngFor="let hero of heroes">
    <span class="badge">{{hero.id}}</span> {{hero.name}}
  </li>
</ul>
```

## *ngIf
```
<div *ngIf="selectedHero">
```

## ngStyle
```
<nz-content [ngStyle]="{'height': height+'px'}" style="padding:0 50px;">
</nz-content>
```
## ngClass
```
[ngClass]="{'text-success':true}"
```
```html
const arr = [1, 3, 4, 5, 6]
<ul>
    <li *ngFor="let item of arr, let i = index">
        <span [ngClass]="{'text-danger': i==0}">{{item}}</span>
    </li>
</ul>
```