+ http://www.voidcn.com/article/p-obhwiznz-btg.html

## 使用方式
#### 子组件
1. 属性定义：
要启用双向数据绑定,您需要在子组件添加对应于该属性的@Output(),并带有“Change”后缀
```
@Input() getVisible: boolean;
@Output() getVisibleChange = new EventEmitter<boolean>();
```
2. 变更通知：
如果要将对属性所做的更改发布到父级,则需要通过以下方式通知父级：
```
this.getVisibleChange.emit(newValue)
```

#### 父组件
双向绑定方式：
```
[(getVisible)]="getVisible"
```
手动回调方式：
```
[getVisible]="myBoundProperty" (getVisibleChange)="myCallback($event)"
```

## 示例场景：
+ `父组件`触发  `弹出框`
+ `弹出框`的内容为`子组件`
+ 子组件 提交表单后，触发父组件属性更改，关闭`弹出框`


### 子组件
#### HTML
```
<button (click)="hide()">test</button>
```

#### TS
双向绑定
+  @Input() getVisible
+  @Output() getVisibleChange，注意比Input的变量名称多了个固定字符串“Change”

```
import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-svg-demo1',
  templateUrl: './svg-demo1.component.html',
  styleUrls: ['./svg-demo1.component.less']
})
export class SvgDemo1Component implements OnInit {
  @Input() getVisible: boolean;
  @Output() getVisibleChange = new EventEmitter<boolean>();

  constructor() {
  }

  ngOnInit() {
  }

  hide() {
    this.getVisible = false;
    this.getVisibleChange.emit(this.getVisible);
    console.log('hide', this.getVisible);
  }
}
```

### 父组件
#### HTML
```
<button nz-button nzType="primary" (click)="showModal()">
  <span>添加APP</span>
</button>
<nz-modal [(nzVisible)]="getVisibles" [nzOkLoading]="isOkLoading"
          (nzOnCancel)="handleCancel()" (nzOnOk)="handleOk()"
          nzTitle="Modal Title"
>
  <app-svg-demo1 [(getVisible)]="getVisible"></app-svg-demo1>
  <app-svg-demo1 [getVisible]="getVisible" (getVisibleChange)="myCallback($event)"></app-svg-demo1>
</nz-modal>
```

#### TS
```
import {Component, OnInit} from '@angular/core';
import {BizAppService} from '../biz-app/biz-app.service';
import {Storage, StorageService} from '../storage/storage.service';
import {ZenContext} from '../../zen-chart/zen-context.model';
import {Lineage} from '../lineage/lineage.model';
import {ZenDemo} from '../../zen-chart/zen-demo.model';
import {BizApp} from '../biz-app/biz-app.model';

@Component({
  selector: 'app-data-index',
  templateUrl: './data-index.component.html',
  styleUrls: ['./data-index.component.less']
})
export class DataIndexComponent implements OnInit {
  app: number;
  apps: BizApp[];
  zenContext = new ZenContext();
  getVisible: boolean;
  isOkLoading = false;

  constructor(private appService: BizAppService,
              private storageService: StorageService) {
  }

  ngOnInit() {
    this.appService.getAll().subscribe(data => {
        console.log('appService', data);
        this.apps = data;
        if (this.apps) {
          this.app = this.apps[0].id;
        }
      }
    );

    // TEST
    ZenDemo.storages.forEach(storage => {
      console.log('storage', storage);
      this.zenContext.addNode(storage.id, storage.name, storage.stage);
    });
    ZenDemo.lines.forEach(line => {
      this.zenContext.addLine(line.fromNodes, line.distNode);
    });
  }

  showModal(): void {
    this.getVisible = true;
  }

  handleOk(): void {
    this.isOkLoading = true;
    setTimeout(() => {
      this.getVisible = false;
      this.isOkLoading = false;
    }, 3000);
  }

  handleCancel(): void {
    this.getVisible = false;
  }

  toggleApp(id: number): void {
    console.log('click toggle app');
    this.zenContext.clean();
    this.storageService.getByAppId(id).subscribe(data => {
      console.log(data);
      this.addStorages(data);
    });
  }

  isOtherStage(stage: string): boolean {
    const stages: Array<string> = ['source', 'etl', ''];
    return stages.findIndex(item => item === stage) < 0;
  }

  addLinage(lines: Lineage[]): void {
    if (!lines) {
      return;
    }
    lines.forEach(line => this.zenContext.addLine(line.fromNodes, line.distNode));
  }

  addStorages(storages: Storage[]): void {
    if (!storages) {
      return;
    }
    storages.forEach(storage =>
      this.zenContext.addNode(storage.id, storage.name, storage.stage));
  }

  myCallback(event): void {
    console.log('myCrazyCallback', event);
    this.getVisible = event;
  }
}

```