+ (click)="onSelect(hero)" 事件
+ {{title}} 插值绑定
+ [(ngModel)] 双向绑定
+ [class.selected]="hero === selectedHero" 样式设置
+ <app-hero-detail [hero]="selectedHero"></app-hero-detail> 单向绑定
# 组件
```
ng generate component alarmRuleList
```
CLI 创建了一个新的文件夹 src/app/heroes/，并生成了 HeroesComponent 的三个文件。

+ 自动导入  src/app/app.module.ts
+ 


## 模块

## 组件

## 指令
### 创建
```
ng generate directive 指令名
```
### 举例
创建unless的指令
```
ng generate directive xx
```
Angular就会在src/app目录下面生成两个文件：xx.directive.ts，xx.directive.spec.ts（指令的测试文件），而且Angular CLI还会将该指令类添加到AppModule的元数据对象的declarations属性中

xx.directive.ts的内容如下

```
import { Directive } from '@angular/core';

@Directive({
  selector: '[appUnless]'
})
export class UnlessDirective {
  constructor() { }
}
```
通过注解@Directive配置指令