## click
```
<li *ngFor="let hero of heroes" (click)="onSelect(hero)">
```


## 鼠标事件
###鼠标按下

```
@HostListener('document:mousedown', ['$event'])
  onDocumentMouseUp(evt: MouseEvent) {
  }
```

### 鼠标移动
```
@HostListener('document:mousemove', ['$event'])
  onDocumentMouseUp(evt: MouseEvent) {
  }
```
### 鼠标抬起
```
@HostListener('document:mouseup', ['$event'])
  onDocumentMouseUp(evt: MouseEvent) {
  }
```


## window事件

### resize
```
@HostListener('window:resize', ['$event'])
onWindowResize(evt) {

}
```