# 双向绑定
[(ngModel)] 是 Angular 的双向数据绑定语法。

{{}}