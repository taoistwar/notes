## 配置路由
`app-routing.module.ts`
```
const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent }
];
```
## 添加路由出口
```
<router-outlet></router-outlet>
```
## 添加路由链接
```
<a routerLink="/dashboard">Heroes</a>
```