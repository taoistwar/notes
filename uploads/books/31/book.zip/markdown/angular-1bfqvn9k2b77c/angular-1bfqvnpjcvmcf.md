## 配置

#### 代理配置
```
{
  "/api": {
    "target": "http://api.yourdomai.com",
    "secure": false
  }
}
```
#### 启动命令
```
ng serve --proxy-config proxy.conf.json --port 0 --open"
```

参考
+ https://www.cnblogs.com/Lulus/p/9261706.html
+ https://stackoverflow.com/questions/37172928/angular-cli-server-how-to-proxy-api-requests-to-another-server