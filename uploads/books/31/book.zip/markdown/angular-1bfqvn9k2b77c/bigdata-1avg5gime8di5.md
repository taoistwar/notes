## 创建项目
```
ng new coral-frontend
```
##　启动项目
```
ng serve --open
```

# 修改应用标题
用你最喜欢的编辑器或 IDE 打开这个项目，并访问 src/app 目录，来对这个起始应用做一些修改。

你会在这里看到 AppComponent 壳的三个实现文件：
+ app.component.ts— 组件的类代码，这是用 TypeScript 写的。
+ app.component.html— 组件的模板，这是用 HTML 写的。
+ app.component.css— 组件的私有 CSS 样式。

## 更改应用标题
打开组件的类文件 (app.component.ts)，并把 title 属性的值修改为 '你自己的标题'。

## 插值绑定
{{title}}

## MD
```
ng add @angular/material
```
# 生成组件

```
ng generate component heroes
```