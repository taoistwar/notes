链接: https://pan.baidu.com/s/143gm0HKyI7q2NDzBCHBazg 提取码: ue6v

使用数据集在这里，里面包含该三个文件：

表一：user_artist_data.txt   包含该的是（用户ID、歌曲ID、用户听的次数）
表二：artist_data.txt   这个文件包含的是（歌曲ID，歌曲名字）
表三：artist_alias.txt   输入错误，或者不同某种原因，同一首歌曲可能具有不同ID，这个是歌曲勘误表（bad_id, good_id）