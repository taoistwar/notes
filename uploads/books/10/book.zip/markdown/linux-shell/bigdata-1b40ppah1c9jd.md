```
#!/usr/bin/env bash
BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
SARRT_DIR=`pwd`
cd $BASE_DIR
nohup java -cp .:bigdata-tools-1.0.1.jar:joda-time-2.10.1.jar:lib.jar bigdata.collector.batch.CollectorBatchApp 2>&1 &
cd ${START_DIR}
```