```
curl -H "Content-Type: application/json" -X POST  --data '{"data":"1"}' http://127.0.0.1/
```