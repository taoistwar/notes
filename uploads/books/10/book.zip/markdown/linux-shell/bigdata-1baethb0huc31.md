#### 查看：
```
crontab -l
```
#### 编辑：
```
crontab -e
```

#### 样例

每天凌晨1点30执行scheduler.sh：
```
30 1 * * * sh /data/service/bigdata-audit/agent-sword/bin/scheduler.sh
```

##### `scheduler.sh`
crontab直接执行的脚本，此脚本执行实际需要执行的kernel.sh。同时，把执行过程保存到日志文件中。
```
#!/usr/bin/env bash
BASE="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
cd $BASE
source /etc/profile

SRC_DATE=`date -d-1day +%Y-%m-%d`
DST_TIME="`echo $[$(date +%s%N)/1000000]`"
LOG_FILE="${BASE}/logs/${SRC_DATE}-${DST_TIME}.log"

if [[ "" = "` ps aux|grep java|grep AuditApp|awk '{print $2}'`" ]] ; then
    echo "${SRC_DATE} starting..." >> ${LOG_FILE}
    sh -x ${BASE}/bin/kernel.sh >> ${LOG_FILE} 2>&1
else 
    echo "${RUN_DATE} is running..." >> ${LOG_FILE}
fi
```
##### `kernel`
```
#!/usr/bin/env bash
BASE="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"

srcDate=`date -d-1day +%Y-%m-%d`
dstYear=`date -d $srcDate +%Y`
dstMonth=`date -d $srcDate +%m`
dstDay=`date -d $srcDate +%d`


cd $BASE/lib
echo "param: $dstYear $dstMonth $dstDay"
./agent $dstYear $dstMonth $dstDay
```


#### crontab的时间格式
格式: [分] [小时] [日] [月] [周] [年]

序号说明是否必填允许填写的值允许的通配符
1. 分是 0-59 , - * /
2. 小时是 0-23 , - * /
3. 日是 1-31 , - * ? / L W
4. 月是 1-12 or JAN-DEC , - * /
5. 周是 1-7 or SUN-SAT , - * ? / L #

#### 通配符说明:
+ `*`表示所有值. 例如:在分的字段上设置 "*",表示每一分钟都会触发。
+ `-`表示区间。例如在小时上设置 "10-12",表示 10,11,12点都会触发。
+ `,`表示指定多个值，例如在周字段上设置 "MON,WED,FRI" 表示周一，周三和周五触发。
+ `/`用于递增触发。
	+ 如在秒上面设置"5-59/15" 表示在5-59秒之间，每增15秒触发(5,20,35,50)。
	+ 在月字段上设置'1/3'所示每月1号开始，每隔三天触发一次。

#### crontab文件的一些例子：
```
30 21 * * * /usr/local/etc/rc.d/lighttpd restart
```
上面的例子表示每晚的21:30重启lighttpd 。
```
45 4 1,10,22 * * /usr/local/etc/rc.d/lighttpd restart
```
上面的例子表示每月1、10、22日的4 : 45重启lighttpd 。
```
10 1 * * 6,0 /usr/local/etc/rc.d/lighttpd restart
```
上面的例子表示每周六、周日的1 : 10重启lighttpd 。
```
0,30 18-23 * * * /usr/local/etc/rc.d/lighttpd restart
```
上面的例子表示在每天18 : 00至23 : 00之间每隔30分钟重启lighttpd 。
```
0 23 * * 6 /usr/local/etc/rc.d/lighttpd restart
```
上面的例子表示每星期六的11 : 00 pm重启lighttpd 。
```
* */1 * * * /usr/local/etc/rc.d/lighttpd restart
```
每一小时重启lighttpd
```
* 23-7/1 * * * /usr/local/etc/rc.d/lighttpd restart
```
晚上11点到早上7点之间，每隔一小时重启lighttpd
```
0 11 4 * mon-wed /usr/local/etc/rc.d/lighttpd restart
```
每月的4号与每周一到周三的11点重启lighttpd
```
0 4 1 jan * /usr/local/etc/rc.d/lighttpd restart
```
一月一号的4点重启lighttpd