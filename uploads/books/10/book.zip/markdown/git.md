### 提交回滚，代码不变，会退到某个未提交的状态（撤销提交）
```bash
git reset --soft head~1
```
1表示回退1个版本
2表示回退2个版本

### 原样提交

```
git config --global core.autocrlf false
```


### 放弃本地已修改代码，强制更新
git强制覆盖：
```
git fetch --all
git reset --hard origin/master
git pull
```
git强制覆盖本地命令（单条执行）：
```
git fetch --all && git reset --hard origin/master && git pull
```
注释：
- git fetch 指令是下载远程仓库最新内容，不做合并
- git reset 指令把HEAD指向master最新版本


### 推送到多个仓库
#### 设置多个URL
为origin仓库添加新URL
```
git remote set-url --add origin https://github.com/niefeilong/struts2project.git
```
提交
```
git push origin --all
```
#### 设置多个仓库
添加仓库
```
git remote add gitee git@gitee.com:taoistwar/sage-bigdata-hive.git
```
更新并提交

```
git pull origin
git push gitee --all
```


## 断点续传
github上的elasticsearch代码库，比较大。数次git clone都因为网络问题没有成功。如下方法：
- 生成空项目
```
mkdir elasticsearch
cd elasticsearch
git init
```
- Fetch仓库
```
$ git fetch git@github.com:elastic/elasticsearch.git
From github.com:elastic/elasticsearch
 * branch            HEAD       -> FETCH_HEAD
```
- checkout FETCH_HEAD
```
 git checkout FETCH_HEAD
```
- git pull
```
git pull
```