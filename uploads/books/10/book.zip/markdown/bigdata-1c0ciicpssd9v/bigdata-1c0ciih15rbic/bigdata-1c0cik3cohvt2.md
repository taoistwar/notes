Log Structured Merge Tree

## Log
每个数据的CRUD都会记录到日志中（WAL）


## 周期性flush在存储中
数据在内存中缓存，周期的