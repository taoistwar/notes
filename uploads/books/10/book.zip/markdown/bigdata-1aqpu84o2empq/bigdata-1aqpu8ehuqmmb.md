#### 告警表 （alarm）
	告警名称（name）、告警类型(type_id)
#### 负责人表（owner）
	姓名（name）、告警类型(type_id)
	
所有负责人(姓名)的需要处理的告警数量

select * from alarm, owner where alarm.type_id = owner.type_id