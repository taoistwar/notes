# 解析框架
https://en.wikipedia.org/wiki/Category:XML_parsers

## Woodstox
## XBlink
## dom4j
## XOM
## jdom

## Castor

## Commons-Digester
## commons-betwixt
## xmlparser
https://mvnrepository.com/artifact/org.tinygroup/org.tinygroup.xmlparser
## pull v2
http://www.xmlpull.org/

# XML-Java绑定
## simple
http://simple.sourceforge.net/home.php

## xstream

## XBlink

## Jackson

## JiBX
绑定XML结构数据到Java对象上的工具,效率是Xstream的3倍

## JAXB

## Jericho

## xmlenc
## xmlbeans