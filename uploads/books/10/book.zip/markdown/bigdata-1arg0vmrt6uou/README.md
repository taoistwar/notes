# 云计算

## IaaS:基础设施即服务。
硬件的管理（虚拟化）



## PaaS：平台即服务。
组件的管理（组件化）

## SaaS：软件即服务。
业务系统的管理（）

![](http://socsight.com/uploads/201811/bigdata/attach_15686add30deb561.png)