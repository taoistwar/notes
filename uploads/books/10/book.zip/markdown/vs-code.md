# 常用快捷键

## 
|   |   |
| ------------ | ------------ |
| Ctrl + P  |	快速文件	|
| Ctrl + Tab |	切换文件   |
| F12 |			类型定义跳转|
| Ctrl + click |	类型定义跳转|
| Alt + F12 |	Peek 定义|
| Ctrl + 鼠标经过 |		提示信息|
| Ctrl + Shift + t |	最后打开的文件|
| Ctrl + Shift + r |	重构	|

## 
|   |   |
| ------------ | ------------ |
| **General**| |
| **Ctrl+Shift+P**, F1 |	快速执行命令	|
| **Ctrl+P** |	快速打开文件	|
| Ctrl+Shift+N |	New window/instance	|
| Ctrl+Shift+W |	Close window/instance	|
| Ctrl+, |	User Settings	|
| **Ctrl+K Ctrl+S** |	快捷键管理	|