## Tutorial
This is a step-by-step tutorial that shows how to build and connect to Calcite. It uses a simple adapter that makes a directory of CSV files appear to be a schema containing tables. Calcite does the rest, and provides a full SQL interface.

Calcite-example-CSV is a fully functional adapter for Calcite that reads text files in CSV (comma-separated values) format. It is remarkable that a couple of hundred lines of Java code are sufficient to provide full SQL query capability.

CSV also serves as a template for building adapters to other data formats. Even though there are not many lines of code, it covers several important concepts:

user-defined schema using SchemaFactory and Schema interfaces;
declaring schemas in a model JSON file;
declaring views in a model JSON file;
user-defined table using the Table interface;
determining the record type of a table;
a simple implementation of Table, using the ScannableTable interface, that enumerates all rows directly;
a more advanced implementation that implements FilterableTable, and can filter out rows according to simple predicates;
advanced implementation of Table, using TranslatableTable, that translates to relational operators using planner rules.