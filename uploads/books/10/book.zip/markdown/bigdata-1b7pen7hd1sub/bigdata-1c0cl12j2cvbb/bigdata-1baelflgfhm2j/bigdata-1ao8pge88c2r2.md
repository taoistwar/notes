# 数据清洗
数据科学项目的第一步，很繁琐。

数据存在严重的**质量问题**，垃圾进垃圾出！

# 使用scala完成所有事情
测试 和 生产 同环境

# 记录关联
record linkage，其它名称 身份解析、记录去重、合并清洗、列表清洗。

大量从一个或多个源系统来的记录，其中有些记录可能代表相同的基础实体。每个实体有若干属性，我们需要根据这些属性找到代表相同实体的记录。

比如购物记录，同一个地址可能有多重写法。如：9号楼、#9。


## 分析示例
加州大学欧文分校机器学习资料库(UC Irvine Machine Learning Repository)，这个资料库为研究和教学提供了大量非常好的数据源，这些数据源非常有意义，并且是免费的。


http://archive.ics.uci.edu/ml/datasets/Record+Linkage+Comparison+Patterns
1. Title: Record Linkage Comparison Patterns 
2. Source Information
   -- Underlying records: Epidemiologisches Krebsregister NRW
      (http://www.krebsregister.nrw.de)
   -- Creation of comparison patterns and gold standard classification:
      Institute for Medical Biostatistics, Epidemiology and Informatics (IMBEI),
      University Medical Center of Johannes Gutenberg University, Mainz, Germany
      (http://www.imbei.uni-mainz.de) 
   -- Donor: Murat Sariyar, Andreas Borg (IMBEI)    
   -- Date: September 2008

### 读数据
```scala
val rawblocks = sc.textFile("E:\\docs\\Spark高级数据分析 第二章（医院数据）\\block_*.csv")

```

### 过滤函数

```scala
def isHeader(line: String): Boolean = {
	line.contains("id_1")
}
```
### 小数据测试函数方法
```scala
rawblocks.first()
val head: Array[String] = rawblocks.take(10)
head.length
head.foreach(println)
head.filter(isHeader).foreach(println)
head.filter(!isHeader(_))
```
### 使用数据
```scala
val rawblocks = sc.textFile("/root/data/block_*.csv")
    val noHeader = rawblocks.filter(!isHeader(_))
    val parsed: RDD[MatchedData] = noHeader.map(parse(_)).cache()
    val matchCounts: collection.Map[Boolean, Long] = parsed.map(_.matched).countByValue()
    matchCounts.toSeq.sortBy(_._2).reverse.foreach(println)


    rawblocks.first()
    val head: Array[String] = rawblocks.take(10)
    head.length
    head.foreach(println)
    head.filter(isHeader).foreach(println)
    head.filter(!isHeader(_))


    head.filter(!isHeader(_)).map(parse).foreach(println)


    noHeader.first()

    val mds = head.filter(!isHeader(_)).map(parse(_))
    val grouped = mds.groupBy(_.matched)
    grouped.mapValues(_.size).foreach(println)


    parsed.map(_.scores(0)).stats()
    parsed.map(_.scores(0)).filter(!java.lang.Double.isNaN(_)).stats()
    val stats: Seq[StatCounter] = (0 until 9).map(i => {
      parsed.map(_.scores(i)).filter(!java.lang.Double.isNaN(_)).stats()
    })
    stats(1)
    val statsm: Seq[NAStatCounter] = statsWithMissing(parsed.filter(_.matched))
    val statsn: Seq[NAStatCounter] = statsWithMissing(parsed.filter(!_.matched))

    val res = statsm.zip(statsn).map { case (m, n) =>
      (m.missing + n.missing, m.stat.mean - n.stat.mean)
    }
    var index = 0
    for (x <- res) {
      println(s"${index}\t${x._1}\t${x._2}")
      index += 1
    }

    def naz(d: Double): Double = if (java.lang.Double.isNaN(d)) 0.0 else d

    case class Scored(md: MatchedData, score: Double)

    val ct = parsed.map(md => {
      val score = Array(2, 5, 7, 8).map(i => naz(md.scores(i))).sum
      Scored(md, score)
    })
    ct.filter(s => s.score >= 4.0).map(_.md.matched).countByValue()
    ct.filter(s => s.score >= 3.0).map(_.md.matched).countByValue()
```


###类库

```
case class MatchedData(id1: Int, dd2: Int, scores: Array[Double], matched: Boolean)


class NAStatCounter extends Serializable {
  val stat: StatCounter = new StatCounter()
  var missing: Long = 0

  def add(x: Double): NAStatCounter = {
    if (java.lang.Double.isNaN(x)) {
      missing += 1
    } else {
      stat.merge(x)
    }
    this
  }

  def merge(other: NAStatCounter): NAStatCounter = {
    stat.merge(other.stat)
    missing += other.missing
    this
  }

  override def toString: String = {
    s"stat:${stat.toString()}, NaN:${missing}"
  }
}

object NAStatCounter {
  def apply(x: Double): NAStatCounter = new NAStatCounter().add(x)
}
```
### 工具方法
```
def isHeader(line: String): Boolean = {
  line.contains("id_1")
}

def parse(line: String): MatchedData = {
  val pieces = line.split(",")
  val id1 = pieces(0).toInt
  val id2 = pieces(1).toInt
  val matched = pieces(11).toBoolean
  val scores: Array[Double] = pieces.slice(2, 11).map { s =>
    if ("?".equals(s)) Double.NaN else s.toDouble
  }
  MatchedData(id1, id2, scores, matched)
}

def statsWithMissing(parsed: RDD[MatchedData]): Seq[NAStatCounter] = {
  parsed.mapPartitions(iter => {
    val nas: Array[NAStatCounter] = iter.next().scores.map(x => NAStatCounter(x))
    iter.foreach(arr => {
      nas.zip(arr.scores).foreach {
        case (n, d) => n.add(d)
      }
    })
    Iterator(nas)
  }).reduce((n1, n2) => n1.zip(n2).map { case (a, b) => a.merge(b) })
}
```