https://flink.sojb.cn/concepts/programming-model.html

# 原生流处理 vs 微批流处理

#