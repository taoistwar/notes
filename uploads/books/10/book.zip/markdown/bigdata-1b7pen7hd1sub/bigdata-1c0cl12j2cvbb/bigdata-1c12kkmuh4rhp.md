## 节点类型
- ResourceManager
- NodeManager

## 资源类型
- Container: 资源的分配的最小单元


## 资源分配
### yarn.nodemanager.resource.memory-mb
每个节点可用内存,单位MB


### mapred.tasktracker.map.tasks.maximum


- CPU数量=服务器CPU总核数 / 每个CPU的核数；
- 服务器CPU总核数
```
more /proc/cpuinfo | grep 'processor' | wc -l
```
- 每个CPU的核数
```
more /proc/cpui nfo | grep 'cpu cores']]
```