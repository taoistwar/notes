# 官方文档
## 中文 （旧版）
https://www.elastic.co/guide/cn/kibana/current/index.html
## 英文 （同版）
https://www.elastic.co/guide/en/kibana/current/index.html

# 旁参
## Elasticsearch: 权威指南　（基于 Elasticsearch 2.x）
https://www.elastic.co/guide/cn/elasticsearch/guide/current/index.html
## Elasticsearch Reference
https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html

# 使用文档
## Discover
### 设置时间过滤器
### 搜索您的数据
+ safari
+ status:200
+ status:[400 TO 499]
+ status:[400 TO 499] AND (extension:php OR (NOT extension:html))
### 根据字段过滤
+ filter
https://www.elastic.co/guide/en/elasticsearch/reference/current/term-level-queries.html
+ 数据列表
+ 左侧字段列表

### 查看文档数据
+ 通过 Advanced Settings 中的 discover:sampleSize 设置表中显示的文档个数
+ 列表字段

### 展示字段数据统计

# 待定
+ 权限隔离