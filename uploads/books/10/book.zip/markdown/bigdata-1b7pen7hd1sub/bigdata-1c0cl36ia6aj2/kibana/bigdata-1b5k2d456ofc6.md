# 添加配置
```
elasticsearch.requestTimeout: 90000
```