```
hive.driver	org.apache.hive.jdbc.HiveDriver
hive.password	hadoop
hive.url	jdbc:hive2://mvp-hadoop26:2181,mvp-hadoop38:2181,mvp-hadoop39:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2
hive.user	hadoop
```


```
	jdbc:hive2://mvp-hadoop26:2181,mvp-hadoop38:2181,mvp-hadoop39:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2;tez.queue.name=finance
```

```
jdbc:hive2://11.84.15.36:8088?mapreduce.job.queuename=队列名
```