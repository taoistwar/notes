## 卸载
如果安装了旧版的docker，需要卸载：
```
yum remove docker \
docker-client \
docker-client-latest \
docker-common \
docker-latest \
docker-latest-logrotate \
docker-logrotate \
docker-selinux \
docker-engine-selinux \
docker-engine
```
## 安装
#### 安装依赖包
```
yum install -y yum-utils device-mapper-persistent-data lvm2
```
#### 添加YUM源
```
yum-config-manager --add-repo https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo
```
#### 安装docker-ce
```
yum-config-manager --enable docker-ce-edge
yum-config-manager enable docker-ce-test
yum makecache fast
yum install docker-ce
```