## Redis 客户端

```
redis-cli -h host -p port -a password
```