# hadoop中备份数修改：

hadoop dfs -setrep [-R] <path> 

如果有-R将修改子目录文件的性质。
hadoop dfs -setrep -w 3 -R /user/hadoop/dir1 就是把目录下所有文件备份系数设置为3.


hadoop dfs -setrep -w 2 -R /data/douyin/origin

# hadoop中查看当前某个文件的备份数：

hadoop dfs -ls [filename]

结果行中的第二列是备份系数 （注：文件夹信息存储在namenode节点上，所以没有备份，故文件夹的备份系数是横杠）

# hadoop集群的检查备份冗余情况：

hadoop fsck / 可以方便的看到各种类型block所占比例。



# 自动负载均衡hadoop文件：
hadoop balancer

# 查看各节点的磁盘占用情况
hadoop dfsadmin -report