技术选型

## 日志收集
- Facebook Scribe
https://github.com/facebook/scribe
- Flume
http://flume.apache.org/

- logstash
http://www.logstash.net/

## BI
- kibana
- zeppelin


## 服务发现
- ZooKeeper
- etcd
- Consul

## RPC
- protobuff
- Avro
- Thrift
- FlatBuffers


## 消息队列
- KAFKA
- RabbitMQ
- StormMQ
- ZeroMQ
- ActiveMQ



## 基础设施
## Iaas
### Kubernetes
### OpenStack
### Docker

## NoSQL
- HBase
- HyperDex
- mongoDB
- RocksDB
- LevelDB
- SSTable

## 集群管理
- Ambari
- Nagios
- Ganglia
- Zabbix
- zipkin

## 存储格式
- RecordIO
对付块数据
- BloomFilter
- Consistent Hashing
- Netty

# 搜索引擎
- ElasticSearch
- Solr
- SenseiDB
- Nutch
- Lucene
- Sphinx

# 机器学习
- Mahout