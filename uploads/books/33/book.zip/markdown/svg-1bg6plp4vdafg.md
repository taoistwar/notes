https://www.cnblogs.com/dxy1982/archive/2012/04/09/2395728.html

## 基本属性
#### x
文本位置坐标

#### y
文本位置坐标

####  text-anchor="middle"
文本显示的方向，其实也就是位置(x,y)处于文本的位置。
这个属性有start,middle和end三种值。