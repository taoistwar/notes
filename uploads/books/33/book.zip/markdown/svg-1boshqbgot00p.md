## 定义
```
<defs>
	<image id="input" width="40" height="40" xlink:href="assets/flow/input.png"/>
</defs>
```

需要有ID属性

## 使用
```
<use x="24" y="42" xlink:href="#input"></use>
```