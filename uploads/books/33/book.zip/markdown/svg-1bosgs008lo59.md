## 属性
### [stroke-dasharray](https://developer.mozilla.org/zh-CN/docs/Web/SVG/Attribute/stroke-dasharray "stroke-dasharray")

用来画虚线，控制虚线各段的长度。

### stroke
边框颜色


### fill
填充颜色