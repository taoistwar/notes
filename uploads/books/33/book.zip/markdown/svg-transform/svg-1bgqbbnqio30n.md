偏移。

沿x轴方向偏移x-value个单位长度，沿y轴方向偏移y-value个单位长度。