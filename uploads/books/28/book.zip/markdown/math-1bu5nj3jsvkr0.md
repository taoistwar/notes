## 省略号
\cdots是横向的省略号
\vdots是竖向的省略号
\ddots是对角线方向的省略号
\ldots 是跟文本底线对齐的省略号