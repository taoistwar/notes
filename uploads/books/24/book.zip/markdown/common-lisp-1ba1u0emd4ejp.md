## 仓库
[传送门](https://github.com/vindarel/cl-str "传送门")

## 安装
```
> (ql:quickload "str")
```
## 使用

```
> (replace-all "a" "o" "faa")
"foo"
T
```