# magit
https://magit.vc/

# Installing from Melpa

https://magit.vc/manual/magit/Installing-from-Melpa.html#Installing-from-Melpa