# 布尔
```
;;; Booleans

t                      ; true; any non-NIL value is true
nil                    ; false; also, the empty list: ()
(not nil)              ; => T
(and 0 t)              ; => T
(or 0 nil)             ; => 0
```

## 逻辑真 vs t
符号 t 是表示逻辑 真 的缺省值。 t 是对自身求值的。
```
> t
T

> 't
T

>  (equal 2 2)
T
```

条件运算，非nil为逻辑真。
```
> (if 0 1 2)
1
> (if nil 1 2)
2
```

## 逻辑假nil
```
> nil
NIL

> 'nil
NIL

>  (equal 2 3)
NIL
```