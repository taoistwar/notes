;;; Pairs

;;; CONS constructs pairs. CAR and CDR return the head and tail of a CONS-pair.

```
> (cons 'SUBJECT 'VERB)
'(SUBJECT . VERB)

> (car (cons 'SUBJECT 'VERB))
SUBJECT

> (cdr (cons 'SUBJECT 'VERB))
VERB
```