## 代码
`hello.lisp`

```
(ql:quickload "drakma") 						   ;1

(defun main()									  ;2
  (format t "~a" *posix-argv*) 					;3
  (format t "hello world") 						;4
  (drakma:http-request "http://www.baidu.com")	 ;5
  (cl-user::quit))								 ;6
```

注：
1. 加载依赖 drakma
2. 定义入口函数
3. 打印命令行参数
4. 打印“hello world”
5. 读取百度页面
6. 退出

## 打包
```
> sbcl --load hello.lisp --eval "(sb-ext:save-lisp-and-die \"hello
.exe\" :toplevel 'main :executable t)"
```

## 运行
`hello.exe`