#### 函数 (#')
```
> (defun hello (x) (format t "hello: ~A~%" x))
HELLO
> (funcall #'hello "xx")
hello: xx
NIL
> (apply #'hello '("xx"))
hello: xx
NIL
```

#### 字符 (#\)
```
> (write-char #\a)
a
#\a
```
#### 整数
##### 16进制 (#x)
```
> #xa
10
```
##### 2进制 (#b)
```
#b111
7
```
##### 8进制 (#o)
```
> #o111
73
```