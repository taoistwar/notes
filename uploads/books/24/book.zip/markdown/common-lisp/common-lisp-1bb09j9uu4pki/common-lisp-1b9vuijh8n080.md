#### eq
```
> (eq 'a 'a)
T

> (eq 2 2)
T

> (atom "xx")
T

> (eq "xx" "xx")
NIL
```
#### eql
同一对象


#### equal 比较 list、string
```
> (equal "ss" "ss")
T

> (equal '(a) '(a))
T

>  (equal #(1) #(1))
NIL
```

#### = 比较数字
```
> (= 2 2.0)
T

> (eq 2 2.0)
NIL

> (eql 2 2.0)
NIL

> (equal 2 2.0)
NIL
```