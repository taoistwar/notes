## atom 原子

原子是多字符的符号（如 forward-paragraph）、单字符符号（如 + 号）、双引号之间的字符串、或者数字。

一个原子是一个数字连续字符或字符串。它包括数字和特殊字符。

+ (atom object) 等价于
+ (typep object 'atom) 等价于
+ (not (consp object)) 等价于
+ (not (typep object 'cons)) 等价于
+ (typep object '(not cons))

说明：(typep object 'atom) 这条语句的含义是: object 的类型是否为 atom，typep 就是一个关于类型的谓词判断函数，因为 atom 既是一个 函数，又是一种 类型 ，在这条语句中 atom 作为 类型 来使用。



###  以下为t (真)
+ 符号
+ 空表
+ t
+ nil
```lisp
(atom 'x)
(atom '())
(atom t)
(atom nil)

```

等价于：
```
(typep object 'atom)
```

### 以下为nil （假）
```lisp
(atom '(x b))
(atom +)
(atom -)
```

## 原子相同eq
(eq x y) 如果x 和 y 的值是同一个原子或都是空表返回 T ， 否则返回空表 () 。
```
> (eq 'a 'a)
T

> (eq '(a) '(a))
NIL
```