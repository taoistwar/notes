# symbol 符号


符号是英语的单词 (words)。一般要使用 quote 来引用它。无论你怎么输入，*通常*会**被转换为大写**：
```
> 'hello
HELLO
```

符号*通常* **不对自身求值**，所以要是想引用符号，应该像上例那样用 ' 引用它。


```
(symbol-function 'a)
(symbol-package 'a)
(symbol-value 'a)
(symbol-plist 'a)
```