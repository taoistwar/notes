## 函数定义
```
(defun function-name (parameter-list)
    "comment"
    (body-list))
```
例：
```
(defun hi()
   "say hello"
   (format t "hello")
   (format t "world"))
```
### 函数参数

#### rest 剩余参数
```
(defun our-funcall (fn &rest args)
  (apply fn args))
```
#### 可选参数
+ 默认值为nil
```
(defun philosoph (thing &optional property)
  (list thing 'is property))
> (philosoph 'death)
(DEATH IS NIL)
```

+ 设置默认值
```
(defun philosoph (thing &optional (property 'fun))
  (list thing 'is property))
> (philosoph 'death)
(DEATH IS FUN)
```


## 函数引用
```
#'hi
(function hi)
```

## 函数调用
### funcall
```
(funcall #'hi)
```
### apply
```
(apply #'hi nil)
```