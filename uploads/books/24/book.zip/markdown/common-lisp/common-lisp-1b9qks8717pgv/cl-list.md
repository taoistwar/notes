## 列表创建 quote, list, cons
Lists are linked-list data structures, made of CONS pairs and end with a NIL (or '()) to mark the end of the list

列表是由被括号包住的零个或多个元素来表示。元素可以是任何类型，包含列表本身。

列表可以想像是二叉树，但是二叉树的左树永远是叶子节点。

列表（1、2、3），如：

```
  |
 / \
1   |
   / \
  2   3
       \
        nil
```

### quote创建列表
+ quote创建列表
```
> '(1 2 3)
(1 2 3)
```
+ 使用列表必须要引用，不然 Lisp 会以为这是个函数调用：
```
> '(+ 2 3)
(+ 2 3)

> (+ 1 2)
3
```
+ 引号保护了整个表达式（包含内部的子表达式），不被求值。
```
> '(+ (- 7 3) 4)
(+ (- 7 3) 4)
```

### list创建列表
由于 list 是函数，所以它的实参会被求值。
```
> (list 1 2)
(1 2)

> (list (+ 1 2))
(3)

> (list + 1 2)
(NIL 1 2)

> (list + 1 2)
((LIST + 1 2) 1 2) ;; // TODO 为何？
```

### cons创建列表
如果传入的第二个实参是列表，则返回由两个实参所构成的新列表，新列表为第一个实参加上第二个实参：
```
> (cons 2 '(1))
(2 1)
```
可以通过把新元素建立在空表之上，来构造一个新列表。
```
> (cons 1 nil)
(1)
```

函数 list ，不过就是一个把几个元素加到 nil 上的快捷方式：
```
> (list 1 2)
(1 2)
> (cons 1 (cons 2 nil))
(1 2)
```

## 空列表
### 括号
```
> ()
NIL
> (listp ())
T
```
### nil
```
> nil
NIL
> 'nil
NIL
```
你不需要引用 nil （但引用也无妨），因为 nil 是对自身求值的。

## 列表函数 car， cdr, cons, third, listp
### car取最顶层二叉树的左子树，是一个叶子节点：
```
> (car '(1 2 3))
1
```

### cdr取最顶层二叉树的右子树
```
(cdr '(1 2 3))
(2 3)
```
即
```
  |
 / \
2   3
     \
     nil
```
### third
取列表第3个值
```
> (third '(1 2 3))
3
> (third '(1 2))
NIL
```

### listp
判断是否是列表
```
> (listp '(1 2 3))
T

> (listp nil)
T

> (listp 1)
NIL
```

### append
```
> (append '(1 2) '(3 4))
(1 2 3 4)
```

### concatenate
```
> (concatenate 'list '(1 2) '(3 4))
(1 2 3 4)
```

### mapcar
```
> (mapcar #'1+ '(1 2 3))
'(2 3 4)

> (mapcar #'+ '(1 2 3) '(10 20 30))
'(11 22 33)

>  (mapcar #'+ '(2 ) '(3 4))
5
```

### remove-if-not
```
> (remove-if-not #'evenp '(1 2 3 4))
(2 4)
```
### every
```
> (every #'evenp '(1 2 3 4))
NIL
```
### some
```
> (some #'oddp '(1 2 3 4))
T
```