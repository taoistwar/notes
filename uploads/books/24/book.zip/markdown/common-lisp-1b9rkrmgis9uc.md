##  定义结构体
```
>  (defstruct dog name breed age)
DOG
```

会自动生成以下几类函数
+ 测试是否为此结构体 DOG-P
+ 结构体实体化 MAKE-DOG
+ 结构体属性访问
  + DOG-NAME
  + DOG-BREED
  + DOG-AGE

## 实例化结构体
```
>(defparameter *rover*
    (make-dog :name "rover"
              :breed "collie"
              :age 5))
*ROVER*

#S(DOG :NAME "rover" :BREED "collie" :AGE 5)
```

## 是否是结构体实例
```
> (dog-p *rover*)
T
```

## 访问结构休属性
```
> (dog-name *rover*)
"rover"
```