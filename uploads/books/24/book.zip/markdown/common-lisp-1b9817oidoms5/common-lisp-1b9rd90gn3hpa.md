```
(do ((variable  initial  update)
	))
```

initial 与 update 形式是选择性的。
若 update 形式忽略时，每次迭代时不会更新变量。
若 initial 形式也忽略时，变量会使用 nil 来初始化。