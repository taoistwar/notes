在 Lisp 中分支条件可由 cond 操作符完成的。

Cond 的形式如下:
```
(cond (p1 e1) (p2 e2)...(pn  en))
```
p1 到 pn 为条件，e1 到 en 为结果，cond 操作符依次对 p1 到 pn 求值，直到找到第一个值为原子 t(真)的p，此时把对应的表达式 e 的值作为整个表达式的值返回。

如：
```
>(cond ((eq 'a 'b) 'first) ((eq '1 '1) 'second))
SECOND
```