# load 加载文件
```
 (load "E:\\workspaces\\lisp\\quicklisp.lisp" :external-format :utf-8)
```

+ :external-format