## string
+ 字符串是长度固定的字符数组。

```
> "Hello, world!"
"Hello, world!"

>  (arrayp "Hello, world!")
T
```

+ “\”是转义字符。

```
> "Benjamin \"Bugsy\" Siegel"
"Benjamin \"Bugsy\" Siegel"
```

+ 字符串可以当作为字符序列（sequence）
```
> (elt "Apple" 0)
#\A
```
```
>
```


```
> "xx"
"xx"
```

## concatenate

```
> (concatenate 'string "Hello, " "world!")
"Hello, world!"
```