## string
特殊的数组，即只有一维的数组，每个元素都是字符。

## array
#### 一维数组
##### 创建数组
```
> (make-array 3 :initial-element nil) ;创建一维数据，长度为3，初始值为nil
#(NIL NIL NIL)

> (vectorp (make-array 1)) ;测试一维数组是否为vector
T
```
##### 数组取值
```
> (aref (make-array 3 :initial-element 1) 0) ;数组是0序
1
```

##### vector
语法糖
```
> #(1 2 3)
#(1 2 3)

> (arrayp #(1 2 3))
T

> (svref #(1 2 3) 2)
3
```
sv是simple vector的缩写。
###### concatenate 'vector
```
> (concatenate 'vector #(1 2 3) #(4 5 6))
#(1 2 3 4 5 6)
```

##### Adjustable vectors
Adjustable vectors have the same printed representation as fixed-length vector's literals.

```
> (make-array '(3) :initial-contents '(1 2 3) :adjustable t :fill-pointer t)
#(1 2 3)
```
###### Adding new elements
```
> (vector-push-extend 4 (make-array '(3) :initial-contents '(1 2 3) :adjustable t :fill-pointer t))
#(1 2 3 4)
```
#### 多维数组
+ make-array创建
```
> (make-array '(2 3) :initial-element nil)
#2A((NIL NIL NIL) (NIL NIL NIL))
```
+ 直接量创建
```
> #2A((NIL NIL NIL) (NIL NIL NIL))

```