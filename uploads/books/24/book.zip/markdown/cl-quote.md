# quote
单引号是 quote 语句的语法糖。
(quote x) 返回x .为了可读性我们把(quote x )简记 为'x
也就是说，形如 '(1 2 3) 的语句实际上就是 (quote (1 2 3 ))，实际执行效果一样

## 语法
```
(quote expr)
```
## 功能及参数
此函数将返回 expr 未判别前的状态。它也可以写成：
```
'expr
```
## 范例
### 无空格
```
(quote a)
'a
```
返回
`A`
### 带空格
```
'|cat xx|
(quote |cat xx|)
```
返回
`|cat xx|`

### quote list
```
(quote (a b))
'(a b)
```
返回
`(A B)`


```
 (car '(car (a b)))
```
`CAR`

```
 (cdr '(car (a b)))
```
`((A B))`