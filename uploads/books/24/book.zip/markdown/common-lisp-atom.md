## 全局变量
```
> (defparameter *some-var* 5)
*SOME-VAR*

> (defvar *some-var* 10)
*SOME-VAR*
```
+ 如果定义一个已经存在的变量时，defvar不会修改变量的值。
defparamter会。

+ 访问一个未定义的变量，会出错。

## 本地变量
```
> (let ((x "xx)) x)
"xx"
```

### 设置变量值
```
(setq x "xx")
```

```
(setf x "xx")
```
### 获取变量值
```
(getf x)
```

从plist获取值
```
(getf (list :书名 "人间词话" :作者 "王国维" :价格 100 :是否有电子版 t) :书名)
```