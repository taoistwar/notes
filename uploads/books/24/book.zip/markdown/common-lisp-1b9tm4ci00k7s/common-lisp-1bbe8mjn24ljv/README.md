```
(uiop:read-file-string bodyFile)
```