### toJson
```
(yason:parse Text :object-as :hash-table)
```

### fromJson
```
(json:encode-json-to-string item)
```