### 解析string
```
> (setf text nil)
(setf es-index (multiple-value-bind (second minute hour day month year)
	       (get-decoded-time)
		 (format nil "oplogs_scheduler_~4,'0d~2,'0d~2,'0d*" year month day)))

(setf url (format nil "http://xxx:9200/~a/_search" es-index))

(setf body (uiop:read-file-string "body.json"))
(setf text (nth-value 0 (drakma:http-request url
					     :method :post
					     :content body
					     :accept "application/json"
					     :content-type "application/json"
					     :basic-authorization '("elastic" "elastic")
					     :want-stream t)))
(setf (flexi-streams:flexi-stream-external-format text) :utf-8)
(setf data (yason:parse Text :object-as :hash-table))
```