#### 转为string

```
>  (setf body (json:encode-json-to-string item ))

```