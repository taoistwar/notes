```
> (cl-ppcre:regex-replace-all "qwer" "something to qwer" "replace")
"something to replace"
```