https://www.quicklisp.org
## 下载
https://beta.quicklisp.org/quicklisp.lisp

## 安装
```
sbcl --load quicklisp.lisp
(quicklisp-quickstart:help)
(quicklisp-quickstart:install)
(ql:add-to-init-file)
```
说明：
+ 帮助 `(quicklisp-quickstart:help)`
+ 安装 `(quicklisp-quickstart:install)`
  ==== quicklisp quickstart install help ====
```
    quicklisp-quickstart:install can take the following optional arguments:
      :path "/path/to/installation/"
      :proxy "http://your.proxy:port/"
      :client-url <url>
      :client-version <version>
      :dist-url <url>
      :dist-version <version>
```
+ 自动加载 `(ql:add-to-init-file)`

## 命令
#### 查找类库
```
(ql:system-apropos "vecto")
```
#### 安装加载类库
```
 (ql:quickload "system-name")
```
#### 升级quicklisp本身
```
(ql:update-client)
```
#### 升级所有安装了的lisp库
```
(ql:update-all-dists)
```
#### 缷载类库
```
(ql-dist:uninstall (ql-dist:release "babel"))
(ql-dist:clean (ql-dist:dist "quicklisp"))
```
#### 查看已安装软件
```
(ql-dist:installed-releases (ql-dist:dist "quicklisp"))
(ql:where-is-system "cl-ppcre")
(ql:register-local-projects)
```
#### 安装配置Slime
```
(ql:quickload "quicklisp-slime-helper")

```