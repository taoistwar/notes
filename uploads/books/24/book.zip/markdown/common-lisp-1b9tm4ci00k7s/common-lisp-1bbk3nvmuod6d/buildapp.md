https://www.xach.com/lisp/buildapp/

```
buildapp --asdf-tree $HOME/quicklisp/dists/quicklisp/software \
  --load-system myapp --entry myapp:main --output hello
```
## 使用
```
C:\Users\Administrator>buildapp --load-system hello --entry hello:main --output hello.exe
```

注：工程hello放在目录`~/common-lisp/`中， 工程 hello 创建参考 "cl-project"

## 安装

### Make安装
```
make install
```

### 手工安装
此种方式，在windows下推荐。
#### 解压
将`buildapp.tgz`解压，然后将文件夹`buildapp-1.5.6 `入在路径`~/common-lisp`。
注意，SBCL默认包含ASDF，而ASDF的默认加载路径是`~/common-lisp`
#### 执行命令
1. 打开SBCL, 进入SBCL命令行交互窗口
```
sbcl --noinform --no-userinit --no-sysinit --disable-debugger
```

2. 加载依赖
```
(require 'asdf)
(require 'buildapp)
```

3. 构建可执行包
```
(buildapp::build-buildapp)
```
注：此步之后，会在当前目录下生成可行包buildapp.exe 或 buildapp (Linux)

4. 退出SBC
```
(exit)
```