通常SBCL已经安装了ASDF
## ASDF
#### 使用ASDF
```
(require "ASDF")
```
注：如果已经安装QuickLisp，那么在QuickLisp中已经执行过此命令。

#### 查看版本
```
(asdf:asdf-version)
```

### 加载系统
```
(asdf:load-system "my-system")
```

## 配置ASDF
#### 默认路径
ASDF 3.1.2 之后，默认的加载路径
```
~/common-lisp/
```
#### source-registry
```
(push "E:/workspaces/lisp/hello/" asdf:*central-registry*)
```
（注意路径结尾的“/”）
可在之前`(asdf:clear-source-registry)`，以清空path

####  配置文件
`~/.config/common-lisp/source-registry.conf.d/`
目录中创建任意文件，比如：myapp.conf。

以下内容，表示递归寻址：
```
(:tree "E:/workspaces/lisp/")
```
#### link farm
`~/.asd-link-farm/`
目录中创建任意文件，比如：myapp.conf
```
(:directory "/home/luser/.asd-link-farm/")
```