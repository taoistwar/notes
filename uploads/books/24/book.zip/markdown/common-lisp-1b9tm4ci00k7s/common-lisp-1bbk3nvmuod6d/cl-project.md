#### 加载cl-project
```
(ql:quickload "cl-project")
```
#### 创建工程
```
(cl-project:make-project #p"hello"
  :author "Your name"
  :email "your@email.com"
  :license "BSD or whatever")
```
注： 在目录 `~/common-lisp/` 下，ASDF 和 Quicklisp 可以直接导入。

##### 添加 Hello World 代码
在 `hello/src/main.lisp` 文件中，添加：
```
(defun hello-world ()
  (format t "Hello world.~%"))

(export 'main)
(defun main (args)
  (hello-world)
  (cl-user::quit))
```

#### 使用 `buildapp` 构建可执行文件
```
buildapp --load-system myapp --entry myapp:main --output hello
```