## 依赖
```
yarn add es6@npm:@elastic/elasticsearch@6
yarn add es7@npm:@elastic/elasticsearch@7
```
##