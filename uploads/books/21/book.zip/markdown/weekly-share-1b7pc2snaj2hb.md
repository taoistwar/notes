```
import java.sql.DriverManager

import org.apache.hive.jdbc.HiveDriver

object HiveTest {
  def main(args: Array[String]): Unit = {
    val driverName =
      "org.apache.hive.jdbc.HiveDriver"
    classOf[HiveDriver]
    val con = DriverManager.getConnection(
      "jdbc:hive2://MVP-HADOOP29:10002/hive", "hadoop", "hadoop");
    val stmt = con.createStatement
    val sql = "select * from  uxin_car_info_origin where dt='2019-05-01' limit 1"
    System.out.println("Running: " + sql)
    val res = stmt.executeQuery(sql)
    if (res.next()) {
      System.out.println(res.getString(1))
    }
  }
}
```