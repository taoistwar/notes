# Hive自定义函数
