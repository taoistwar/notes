https://blog.csdn.net/beauty0522/article/details/78461385

# int	instr(string str, string substr)

返回substr在str中第一次出现的位置。若任何参数为null返回null，若substr不在str中返回0。Str中第一个字符的位置为1