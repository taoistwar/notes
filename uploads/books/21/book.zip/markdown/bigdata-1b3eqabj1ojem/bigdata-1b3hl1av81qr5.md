# evaluator.Mode
| Mode | MR阶段 | 遍历方法 | 输出方法 | 说明 |
| ------------ | ------------ | ------------ | ------------ |---|
| PARTIAL1  | map  |  iterate() |  terminatePartial() |从原始数据到部分数据聚合|
| PARTIAL2  | Combiner  | merge()  | terminatePartial()  |负责在map端合并map的数据；从部分数据聚合到部分数据聚合 |
| FINAL | reduce | merge() | terminate() |从部分数据的聚合到完全聚合|
| COMPLETE | only map |iterate() | terminate() |  如果出现了这个阶段，表示mapreduce只有map，没有reduce，所以map端就直接出结果了；从原始数据直接到完全聚合 |

#