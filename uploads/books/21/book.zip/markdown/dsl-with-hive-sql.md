Hive 是基于SQL的DSL。
DSL是声明式编程的子范式，SQL语言是一种DSL。
# 背景
## 声明式编程
+ 定义做什么，非怎么做。
+ 子范式:
	+ 约束式编程
	+ 领域专属语言
	+ 函数式编程
	+ 逻辑式编程

## DSL
+ 领域特定语言（英语：domain-specific language、DSL）指的是专注于某个应用程序领域的计算机语言。又译作领域专用语言。
+ 针对某一领域，具有受限表达性的一种计算机程序设计语言。

DSL最大的作用是屏蔽无关的噪音，专注于业务领域内的本质问题。

+ 内部DSL：
用通用语言的语法表示DSL，需要按照某种风格使用这种语言。

+ 外部DSL：
在主程序设计语言之外，用一种单独的语言表示领域专有语言。可以是定制语法，或者遵循另外一种语法，如XML，SQL。

# SQL
SQL是一种DSL语言.
## 语法

### JOIN
| 名称   | 说明  |
| ------------ | ------------ |
| INNER JOIN	| 只连接匹配的行  |
| LEFT JOIN		| 产生表1的完全集，而2表中匹配的则有值，没有匹配的则以null值取代。  |
| RIGHT JOIN	| 产生表2的完全集，而1表中匹配的则有值，没有匹配的则以null值取代。|
| FULL JOIN		| 产生表1和表2的并集。但是需要注意的是，对于没有匹配的记录，则会以null做为值 |
#### 数据
| id  |  name || id  |  address |
| ------------ | ------------ |
|1	|Google||1	|美国|
|2	|淘宝||5	|中国|
|3	|微博||3	|中国|
|4	|Facebook||6	|美国|




#### INNER JOIN
只连接匹配的行
![](http://socsight.com/uploads/201903/weekly-share/attach_1590b9cf4500f141.png)
```
SELECT * FROM t1 INNER JOIN t2 on t1.id = t2.id
```

![](http://socsight.com/uploads/201904/weekly-share/attach_1591875dea52bab0.png)

```
SELECT * FROM t1 , t2 where t1.id = t2.id
```
#### LEFT JOIN
![](http://socsight.com/uploads/201903/weekly-share/attach_1590b9daece360c9.png)
```
SELECT * FROM t1 left join t2 on t1.id = t2.id
```

![](http://socsight.com/uploads/201904/weekly-share/attach_159187938d43eb0c.png)
#### RIGHT JOIN
![](http://socsight.com/uploads/201903/weekly-share/attach_1590b9e5019827f5.png)
```
SELECT * FROM t1 right join t2 on t1.id = t2.id
```
![](http://socsight.com/uploads/201904/weekly-share/attach_159187a7713044a4.png)
#### FULL JOIN
![](http://socsight.com/uploads/201903/weekly-share/attach_1590b9ec2ee30bd2.png)


## 场景
### group by having
+ group by 将整个数据集合按条件分隔成很多个小数据集合
+ having  挑选符合条件的小数据集合

```
select car_id from uxin_car_info_all_snapshot
where dt='2019-03-06'
group by car_id having count(1) > 1;
```