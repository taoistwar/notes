# 去重
## dense_ran()
场景：两个人并列第1，后续的值为2
|函数   |场景   |
| ------------ | ------------ |
|rank		| 两个人并列第1，后继的值为3  |
|dense_ran	| 两个人并列第1，后续的值为2  |
|row_number	| 不存在并列，序号不重 |

## row_number
```
select *
from (
  select  *,row_number() over (partition by id order by occur_timestamp desc) as order_num 
  from
    bigdata.xxx where dt='2019-01-22'
) dd2 where dd2.order_num=1;
```

`row_number() over (partition by id order by occur_timestamp desc) as order_num`

`order_num=1`

```
SELECT tel, link_name, certificate_no, certificate_type, modify_time
  FROM order_info
 WHERE deleted = 'F'
   AND pay_status = 'payed'
   AND create_time >= to_date('2017-04-23', 'yyyy-MM-dd')
   AND create_time < to_date('2017-04-24', 'yyyy-MM-dd')
   AND row_number() over(PARTITION BY tel ORDER BY tel DESC) = 1
```
 


https://www.cnblogs.com/wujin/p/6051768.html