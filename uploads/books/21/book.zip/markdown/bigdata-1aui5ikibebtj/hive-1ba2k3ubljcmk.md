4秒内连续算一个会话

|  row | value1  |value2   |res   |   |
| ------------ | ------------ | ------------ | ------------ | ------------ |
| 1  | -  | 3  | -  |   |
| 2  | 3  | 4  | ×  |   |
| 2  | 4  | 5  | ×  |   |
| 2  | 5  | 10  | ×  |   |
| 2  | 10  | 15  | √  | 10  |
| 2  | 20  | 25  | √  | 20  |
| 2  | 25  | 30  | √  | 25  |
| 2  | 30  | 31  | ×  |   |
| 2  | 31  | -   | -  |  31  |


|  row | value1  |value2   |res   |   |
| ------------ | ------------ | ------------ | ------------ | ------------ |
| 1  | -  | 3  | -  |   |
| 2  | 3  | 4  | ×  |   |
| 2  | 4  | 5  | ×  |   |
| 2  | 5  | 10  | ×  |   |
| 2  | 10  | 15  | √  | 10  |
| 2  | 20  | 25  | √  | 20  |
| 2  | 25  | 30  | √  | 25  |
| 2  | 30  | 35  | √  | 30  |
| 2  | 35  | -   | -  | 35 |

```

    select a.room_id,a.audience_id,a.gift_id,
    a.gift_num a_gift_num,b.gift_num b_gift_num,
    a.data_generate_time a_data_generate_time,b.data_generate_time b_data_generate_time,
    case
        when b.data_generate_time-a.data_generate_time<${interval}
         and a.gift_num<b.gift_num
         or b.data_generate_time=a.data_generate_time
        then 0
    else 1
    end tag
    from
    (select
        room_id,audience_id,gift_id,gift_num,data_generate_time,
        row_number() over(partition by room_id,audience_id,gift_id order by data_generate_time asc) row_id
    from bigdata.bili_danmu_gift_info_daily_tmp1) a
    join
    (select
        room_id,audience_id,gift_id,gift_num,data_generate_time,
        row_number() over(partition by room_id,audience_id,gift_id order by data_generate_time asc) row_id
    from bigdata.bili_danmu_gift_info_daily_tmp1) b
    on a.row_id=b.row_id-1 and a.room_id=b.room_id and a.audience_id=b.audience_id and a.gift_id=b.gift_id;
```