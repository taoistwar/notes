```

collect_wc('-', collect_set(field))
```

需求：对用户的信息进行分析，相同用户的地址信息按照不同类型分别展示出来，每个用户一行。

table1:

| user_id  | location  | location_type  |
| ------------ | ------------ | ------------ |
| 123  | l1  | home  |
| 123  | l2  | work   |

目标：

| user_id  | location   |
| ------------ | ------------ |
|  123 | l1-l2  |

```
 select user_id, concat_ws('-',collect_set(location)) as location,
 from  table1
 group by user_id
```