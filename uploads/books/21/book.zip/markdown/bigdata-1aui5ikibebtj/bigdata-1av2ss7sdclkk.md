## 车辆表 t_car
id
name

## 已售 t_had_sale
id
## 下架 t_off_sale
id

# 车辆信息、是否已售、是否下架
```sql
SELECT
	t1.*,
	t2.id,
	t3.id
FROM
	t_car t1
LEFT JOIN t_had_sale t2 ON t1.id = t2.id
LEFT JOIN t_off_sale t3 ON t1.id = t3.id
```
![](http://socsight.com/uploads/201901/bigdata/attach_157c24885d1269b1.png)