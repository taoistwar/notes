# 添加依赖
https://www.elastic.co/guide/en/elasticsearch/hadoop/6.3/hive.html


# 配置说明 
TBLPROPERTIES配置项
https://www.elastic.co/guide/en/elasticsearch/hadoop/6.3/configuration.html
##  es.mapping.names
```
'es.mapping.names' = 'occur_date:timestamp, url:url_123'
```
## es.resource

### es.resource.read
- 只能读取，不能写入。
- 可以设置多个index和type。

配置样例　
```
es.resource.write = soc_*/data,logs
```

### es.resource.write
- 只能写入，不能读取。
- 不能设置多个index和type。 但能通过设置动态模板，进行分表、分区。
- 可以根据若干个属性，设置到对应的index和type。




index、type动态配置：
数据
```
{
    "media_type":"game",
    "title":"Final Fantasy VI",
    "year":"1994"
},
{
    "media_type":"book",
    "title":"Harry Potter",
    "year":"2010"
},
{
    "media_type":"music",
    "title":"Surfing With The Alien",
    "year":"1987"
}
```
配置
```
es.resource.write = soc_{year}/{media_type}
```
结果

| index  |type   |title|
| ------------ | ------------ |
| soc_1994	 | game	| Final Fantasy VI	|
| soc_2010	| book	| Harry Potter	|
| soc_1987	| music	| Surfing With The Alien	|

### es.mapping.id
```
es.mapping.id='car_id'
```
ES 数据的_id字段，配置使用指定的字段
### es.resource.write
```
'es.resource.write' = 'used_car_d_{stat_date}/data'
```
ES 数据的_index和_type，配置使用指定的字段



# 读取ES
```
add jar hdfs:/data/lib/es/elasticsearch-hadoop-6.3.2.jar;
add jar hdfs:/data/lib/es/commons-httpclient-3.1.jar;
```
### 不分区
#### 样例一
```sql
create EXTERNAL  table es_test(
car_id string,
share_link string
)
STORED BY 'org.elasticsearch.hadoop.hive.EsStorageHandler'
TBLPROPERTIES(
'es.resource' = 'uxin_test_2019-01-04/data',
'es.nodes' = 'mvp-hadoop40,mvp-hadoop41,mvp-hadoop42',
'es.port' = '9200',
'es.nodes.wan.only'='true');
```

#### 样例二
```sql
CREATE EXTERNAL TABLE `bigdata.uxin_car_info_origin_es_20190103` (
`car_id` string COMMENT '车辆ID',
`car_name` string COMMENT '车辆名称'
)
STORED BY 'org.elasticsearch.hadoop.hive.EsStorageHandler'
TBLPROPERTIES(
    'es.nodes' = 'mvp-hadoop40,mvp-hadoop41,mvp-hadoop42',
    'es.port' = '9200',
    'es.resource' = 'used_car_r_20190103/data',
    'es.nodes.wan.only'='true');
```
### x-pack认证
```
CREATE EXTERNAL TABLE `sword_r_es`(
  `meta_table_name` string COMMENT 'from deserializer',
  `string_time` string COMMENT 'from deserializer')s
STORED BY 
  'org.elasticsearch.hadoop.hive.EsStorageHandler'
TBLPROPERTIES ( 
  'es.nodes'='mvp-hadoop172',
  'es.nodes.wan.only'='true',
  'es.port'='9200',
  'es.resource'='audit/data',
  'es.net.http.auth.user'='elastic',
  'es.net.http.auth.pass'='elastic'
)
```

```
alter table table_name set tblproperties('es.net.http.auth.user'='elastic');
alter table table_name set tblproperties('es.net.http.auth.pass'='elastic');

```
### 分区读取ES

```
CREATE EXTERNAL TABLE `bigdata.uxin_car_info_origin_es` (
`occur_timestamp` TIMESTAMP COMMENT '爬取日期',
`car_id` string COMMENT '车辆ID',
`price` BIGINT COMMENT '车辆报价',
`car_name` string COMMENT '车辆名称',
`brand` string COMMENT '车辆品牌',
`mode` string COMMENT '型号',
`year` BIGINT COMMENT '车辆年款',
`gear_box` string COMMENT '变速箱',
`version` string COMMENT '车型',
`down_payment` BIGINT COMMENT '首付',
`month_payment` BIGINT COMMENT '月付',
`nationwide_purchase` BIGINT COMMENT '全国购',
`special_offer` BIGINT COMMENT '超值',
`return_car_3_days` BIGINT COMMENT '三天无理由退车',
`certificate` string COMMENT '认证类型',
`warehouse` string COMMENT '货仓',
`registration_date` TIMESTAMP COMMENT '车辆上牌日期',
`apparent_mileage` string COMMENT '表显里程',
`emission_standards` string COMMENT '排放标准',
`car_color` string COMMENT '颜色',
`engine_intake` string COMMENT '发动机类型',
`lift_time_min` string COMMENT '最快提车时间',
`lift_time_max` string COMMENT '最慢提车时间',
`engine_exhaust` string COMMENT '发动机排量',
`check_people` string COMMENT '检测员',
`check_date` TIMESTAMP COMMENT '检测时间',
`last_maintenance_date` TIMESTAMP COMMENT '最后一次维保时间',
`fix_times` string COMMENT '维修次数',
`maintenance_times` string COMMENT '保养次数',
`accident_times` string COMMENT '事故次数',
`share_link` string COMMENT '分享链接'
)
STORED BY 'org.elasticsearch.hadoop.hive.EsStorageHandler'
TBLPROPERTIES(
    'es.nodes' = 'mvp-hadoop40,mvp-hadoop41,mvp-hadoop42',
    'es.port' = '9200',
    'es.resource.read' = 'used_car_r_*/data',
    'es.nodes.wan.only'='true',
  'es.mapping.names' = 'occur_timestamp:timestamp');
```

# 写入ES


## 操作流程
```
add jar hdfs:/data/lib/es/elasticsearch-hadoop-6.3.2.jar;
add jar hdfs:/data/lib/es/commons-httpclient-3.1.jar;
```
### 建表
```
CREATE EXTERNAL TABLE `bigdata.uxin_car_info_snapshot_es` (
`timestamp` TIMESTAMP  COMMENT 'ES分片',
`occur_timestamp` TIMESTAMP COMMENT '爬取日期',
`car_id` string COMMENT '车辆ID',
`stat_date` string COMMENT '日期index',
`meta_table_name` string,
`meta_app_name` string
)
STORED BY 'org.elasticsearch.hadoop.hive.EsStorageHandler'
TBLPROPERTIES(
    'es.nodes' = 'mvp-hadoop40,mvp-hadoop41,mvp-hadoop42',
    'es.port' = '9200',
    'es.resource.write' = 'used_car_d_{stat_date}/data',
    'es.nodes.wan.only'='true');
```
### 写数据
```
insert into bigdata.uxin_car_info_snapshot_es
select unix_timestamp('2019-01-09', 'yyyy-MM-dd')*1000,
unix_timestamp(substr(occur_timestamp, 2, 19), 'yyyy-MM-dd HH:mm:ss')*1000,
car_id,price,
 '20190109',
 'car_info',
 'uxin'
 from bigdata.uxin_car_info_snapshot where dt = '2019-01-09';


```