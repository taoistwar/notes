# 建表
```
CREATE EXTERNAL TABLE `renren_bak`(
  `data` STRING
)
PARTITIONED BY (dt STRING)
ROW FORMAT
    DELIMITED FIELDS TERMINATED BY '\u0001'
    LINES TERMINATED BY '\n'
STORED AS TEXTFILE
LOCATION '/data/renren/bak';
```
# 添加分区
```
alter table renren_bak add IF NOT EXISTS partition (dt='2019-04-27') location '/data/renren/bak/2019-04-27';
```
# 模糊查询
```
select count(*) from bigdata.renren_bak where dt ='2019-04-27' and instr(data, '这辆车已经卖掉') >0;
```


27 12