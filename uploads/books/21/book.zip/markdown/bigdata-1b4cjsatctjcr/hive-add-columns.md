# 添加字段
Add/Replace Columns
## 语法
```sql
ALTER TABLE table_name ADD|REPLACE COLUMNS (col_name data_type [COMMENT col_comment], ...)
```

## 样例
```
CREATE EXTERNAL TABLE
IF NOT EXISTS `bigdata.uxin_car_had_sale_origin` (
`occur_timestamp` string COMMENT '爬取日期',
`car_id` string COMMENT '车辆ID'
)
PARTITIONED BY (dt STRING, hour STRING)
ROW FORMAT
DELIMITED FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
LOCATION '/data/uxin/origin/car_had_sale';


alter table `bigdata.uxin_car_had_sale_origin` add columns(
  `price` INT COMMENT '车辆报价'
);
```