```
alter table bigdata.uxin_car_had_sale_mix_snapshot set location 'hdfs:///data/uxin/snapshot/car_had_sale_mix';
```