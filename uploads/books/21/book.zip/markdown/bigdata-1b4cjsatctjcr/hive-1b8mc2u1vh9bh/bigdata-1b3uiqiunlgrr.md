# 表改名
```
ALTER TABLE name RENAME TO new_name
```