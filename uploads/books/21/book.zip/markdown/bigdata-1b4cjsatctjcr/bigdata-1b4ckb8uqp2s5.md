# 根据使用的引擎设置队列

hive 设置队列需要根据所使用的引擎进行对应的设置才会有效果，否则无效

设置引擎

set hive.execution.engine=mr;
set hive.execution.engine=spark;
set hive.execution.engine=tez;

如果使用的是mr(原生mapreduce)
SET mapreduce.job.queuename=etl;

如果使用的引擎是tez
set tez.queue.name=etl
设置队列（etl为队列名称，默认为default）