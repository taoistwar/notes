## 查看 
```
show partitions uxin_car_info_origin;
```
##  删除
```
alter table uxin_car_had_sale_snapshot drop partition(dt='2019-03-10');
```

## 修改
```
ALTER TABLE bigdata.uxin_car_had_sale_mix_snapshot PARTITION (dt='2019-03-27') SET LOCATION 'hdfs://HaimaNX/data/uxin/snapshot/car_had_sale_mix/dt=2019-03-27'
```


## 添加
```
alter table bigdata.uxin_car_info_origin add IF NOT EXISTS partition (dt='$date', hour='22') location '/data/uxin/origin/car_info/$date/22';
```