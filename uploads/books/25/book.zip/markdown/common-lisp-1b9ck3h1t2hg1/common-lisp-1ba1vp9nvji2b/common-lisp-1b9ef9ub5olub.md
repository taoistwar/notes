# Emacs配置
如何找到初始化文件
Emacs会在系统中寻找一个名为HOME的变量，然后拷贝一个副本供自己使用，并在其指定的路径下寻找配置文件。

emacs配置文件有两个位置：~/.emacs和~/.emacs.d/init.el

我在Windows下，通常使用默认位置的~/.emacs。然后在.emacs中定制.emacs.d的位置。

## .emacs文件变量
user-init-file
## .emacs.d目录变量
user-emacs-directory


## 加载新的初始化文件
```lisp
;; 重新定义HOME环境变量
(setenv "HOME" "C:/Users/Administrator")
;; 设定默认的文件加载路径
(setq default-directory "~/")

;; 加载指定的配置文件，注意这条语句应该放在后面
;; 因为环境首先需要上面的语句初始化
;; 如果加载的文件中有依赖环境的，必须先初始化环境
(setq user-emacs-directory "D:/dev/emacs-26.2-x86_64")
(load-file "D:/dev/emacs-26.2-x86_64/.emacs.d/init.el")
```


## HOME目录
### windows注册表定制
```
[HKEY_CURRENT_USER\Software\GNU\Emacs]
"HOME"="自己的路径"
```
### 默认目录
windows平台，在cmd使用echo %userprofile%来查看HOME。
### Win7配置文件目录：
C:\Users\taoistwar\AppData\Roaming
http://www.cnblogs.com/wendellyi/archive/2013/06/06/3122737.html
### Win10配置文件目录：
C:\Users\taoistwar\

## 配置文件
### Emacs手工创建
1. C-x C-f ~/.emacs

### Emacs自动创建
直接修改emacs的一些配置让emacs自己生成.emacs文件。下面通过配置Emacs的光标是否闪烁来生成配置文件。

1. 输入M-x customize ![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cf906c4c059d.png)
2. 进入Environment ![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cf9d79620af1.png)
3. 进入Frames ![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfa4d8df1c1f.png)
4. 进入Cursor(在下面) ![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfaf8e78b5de.png)
5. 找到Blink Cursor Mode把光标停在三角上按回车 ![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfb899a549ba.png)
6. 把光标移到“Toggle”上按回车后面的on会变成off ![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfc41a72e890.png)
7. 把光标移到State上按回车再按1（就是保存）![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfddc6d24fcc.png)
![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfe68f4a1aca.png)
8. 在Mini窗口中显示.emacs文件的路径
![](http://socsight.com/uploads/201906/common-lisp/attach_15a5cfec5934c753.png)
9. 使配置生效，可以重启，也可以M-x eval-buffer