##　windows

`install.bat`
```
msiexec /i sbcl-1.4.14-x86-64-windows-binary.msi
```
右键 -> 以管理员身份运行