## 配置
```
;; melpa
(require 'package)
(package-initialize)
(setq package-archives '(("gnu"   . "http://elpa.emacs-china.org/gnu/")
                           ("melpa" . "http://elpa.emacs-china.org/melpa/")))
```

## 更新包
```
M-x package-refresh-contents
```