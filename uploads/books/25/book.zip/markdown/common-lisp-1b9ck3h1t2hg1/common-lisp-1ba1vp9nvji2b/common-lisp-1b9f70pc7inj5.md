## 安装SBCL
[传送门](http://socsight.com/docs/common-lisp/install-sbcl "传送门")

## quicklisp 方式（推荐）

#### 使用quicklisp安装slime
```
(ql:quickload "quicklisp-slime-helper")
```
#### emacs配置
```
(load (expand-file-name "~/quicklisp/slime-helper.el"))
```

## elpa方式
#### 使用MELPA安装Slime
```
M-x package-install RET slime RET
```
#### 配置Slime
```
~/.emacs
;; Set your lisp system and, optionally, some contribs
(setq inferior-lisp-program "d:/dev/sbcl/sbcl.exe")
(require 'slime-autoloads)
(slime-setup)
(slime-setup '(slime-fancy slime-banner))
```
## 启动
```
M-x slime
```
## 使用
代码编辑完成后 
+ C-c C-c，自动使用slime执行代码。
+ C-c C-z 可以直接调出一个关联到当前文本编辑界面的 REPL 窗口
+ C-c C-y 把光标所在区域的函数名称发送到对应的 REPL 进程中，非常方便调试代码


### 移动 
+ C-M-f paredit-forward 光标移动到括号后
+ C-M-b paredit-backword 光标一定到括号前

### 编辑 
+ C-M-Space mark-sexp 选中光标所在的S表达式
C-M-t transpose-sexps 
将两个S表达式变换位置 
(... 
(one) 
|(two) 
...) 
(... 
(one) 
(two)| 
...) 

M-1 ( 
在当前S表达式外添加一对括号 
(... 
(do) 
...) 
(... 
((do)) 
...) 

M-1 C-k 
删除光标所在的S表达式 
(... 
(do) 
...) 
(... 
...) 

M-; paredit-comment-dwin 
添加注释 
M-s paredit-splice-sexp 
删除外面的一对括号 
((do)) 
(do) 

M-r paredit-raise-sexp 
删除外面的一对括号，连同内容 
(... 
(do) 
...) 
(do) 

C-) paredit-backward-slurp-sexp 
将后面的括号向后移动一个元素 
(a b (c| d) e f) 
(a b (c| d e) f) 

C-} paredit-backward-barf-sexp 
将后面的括号向前移动一个元素 
(a b (c| d e) f) 
(a b (c| d) e f) 

C-( paredit-forward-slurp-sexp 
将前面的括号向前移动一个元素 
(a b (c| d) e f) 
(a (b c| d) e f) 

C-{ paredit-forward-barf-sexp 
将前面的括号向后一点一个元素 
(a (b c| d) e f) 
(a b (c| d) e f) 

C-c C-q slime-close-parens-at-point 
C-c C-] slime-close-all-sexp 

对齐 
C-M-\ indent-region 
C-c M-q slime-reindent-defun 

文档相关 
C-c C-d d slime-describe-symbol 
C-c C-d a slime-apropos 
C-c C-d h slime-hyperspec-lookup 
C-d C-c C-f slime-describe-function 
C-c I slime-inspect 
M-. slime-edit-definition 

#### 编译
C-c C-c slime-compile-defun 
C-c C-k slime-compile-and-load-file 

#### 宏扩展
C-c C-m slime-macroexpand-1 
C-c M-m slime-macroexpand-all 

调试 
C-c C-t slime-toggle-trace-fdefination 

repl 
C-c C-z slime-switch-to-output-buffer 
M-n slime-repl-next-input 
M-p slime-repl-previous-input 
, slime-handle-repl-shortcut 
* 表示前一个表达式的返回值 
+ 表示后一个表达式的返回值