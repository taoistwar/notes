##### 在emacs中，您可以为任何命令创建任何键盘快捷键。
```
(global-set-key (kbd "M-a") 'backward-char) ; Alt+a

(global-set-key (kbd "C-a") 'backward-char) ; Ctrl+a

(global-set-key (kbd "C-c t") 'backward-char) ; Ctrl+c t

(global-set-key (kbd "<f7> <f8>") 'whitespace-mode)    ; F7 F8
```

##### 查看现有键，绑定的命令
```
describe-key