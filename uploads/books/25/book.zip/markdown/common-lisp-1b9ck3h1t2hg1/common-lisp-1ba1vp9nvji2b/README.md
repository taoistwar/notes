## 大虾的配置

[Steve Purcell](https://github.com/purcell/emacs.d)

[Andy Stewart's emacs](https://github.com/manateelazycat/lazycat-emacs)

[Doom Emacss](https://github.com/hlissner/doom-emacs)

## 插件列表
+ smex
+ company
+ elpa
+ org-mode
+ slime
+ yasnippet

## 命令

(global-set-key (kbd "C-j") 'goto-line)