## 官方网站
http://orgmode.org
### 其它参考
[Org-mode 简明手册](https://www.cnblogs.com/Open_Source/archive/2011/07/17/2108747.html)

[Orgmode for GTD](https://emacs.cafe/emacs/orgmode/gtd/2017/06/30/orgmode-gtd.html "Orgmode for GTD")
[LITERATE PROGRAMMING WITH ORG-MODE](http://cachestocaches.com/2018/6/org-literate-programming/)
[Org Mode - Organize Your Life In Plain Text!](http://doc.norang.ca/org-mode.html)

## 节点
`M - →`  增加节点层数(子节点忽略)
`M - S →`  增加节点层数（子节点一起增加）
`M - ↑`    上移节点

## GTD
Get things done
### 任务(task)
在 Org 中，对应的专业名词叫 Headline , 如果一行文本是以一个或多个「*」开头， 空 格后跟一段文本，那么这一行就是 Headline ，那段文本就是我们想要定义的某个具体任务。
一个任务的子任务，在Org中的表示方式很简单，在任务下方新起一行，并比该任务多一 个「*」即可。
子任务的子任务怎么表示，同样方法，在子任务下方再多一个「*」开头的任 务就好了。
```
* 任务1
** 子任务1
*** 子任务1的子任务
```

### 附件
```
C-c C-a
```
+ `n` 新建
+ `o` 打开

### 大冈视图
+ `<SHIFT>-<TAB>` 对当前文件进行切换：收缩→查看所有子结点→查看所有内容
+ `<TAB>` 对当前结点进行切换：收缩→查看所有子结点→查看所有内容

### 任务


### 状态：
+ `C-c C-t`是在定义的状态中循环
+ `C-u C-c C-t`可以指定一个状态
+ `S－Right` 切换状态
+ `S－Left` 切换状态


### 优先级：
+ `C-c ,` 可以设置一个TODO项目的优先级
+ `S - Up`    切换优先级
+ `S - Down`    切换优先级
### 日期：
时间点
时间段
+ `C-c .`	询问日期并输入正确的时间戳。
当光标处理一个时间戳之上时，是修改这个时间戳，而不是插入一个新的。如果这个命令连用再次，就会插入一个时间段。加上前缀会附带当前时间。
+ `C-c !`	功能同C-c .，但是插入的是一个未激活的时间戳。
+ S-LEFT/RIGHT	将光标处理的时间戳改变一天。
+ S-UP/DOWN	改变时间戳中光标下的项。
光标可以处在年、月、日、时或者分之上。当时间戳包含一个时间段时，如 “15:30-16:30”，修改第一个时间，会自动同时修改第二个时间，以保持时间段长度不变。想修改时间段长度，可以修改第二个时间。

## 快捷键
### 移动

C-c C-n	下个标题	
C-c C-p	上个标题	
C-c C-f	下个同级的标题	
C-c C-b	上个同级的标题	
C-c C-u	回到上层标题	

### 节点移动


M-<LEFT>	减少节点层级	
M-<RIGHT>	增加节点层级	
M-<UP>	将节点向上移动	
M-<DOWN>	将节点向下移动	
M-<ENTER>	增加一条同级节点