```
(package-initialize)

(add-to-list 'load-path "~/.emacs.d/lisp/")

(require 'init-packages)
(require 'init-ui)
(require 'init-custom)
(require 'init-org)
(require 'init-keys)
(require 'init-defaults)
```