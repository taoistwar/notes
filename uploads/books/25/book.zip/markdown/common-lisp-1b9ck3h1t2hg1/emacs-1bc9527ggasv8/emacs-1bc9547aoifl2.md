```
;; elpa
(when (>= emacs-major-version 24)
  (require 'package)
  (setq package-archives '(("gnu"   . "http://mirrors.tuna.tsinghua.edu.cn/elpa/gnu/")
                           ("melpa" . "http://mirrors.tuna.tsinghua.edu.cn/elpa/melpa/")))
  (package-initialize))

;; 你可以将你需要的插件名字写在 my/packages 中，Emacs 在启动时会自动下载未被安装 的插件
;; cl - Common Lisp Extension
(require 'cl)
;; Add Packages
(defvar my/packages '(
                      ;; --- Auto-completion ---
                      company
                      ;; --- Better Editor ---
                      hungry-delete
                      swiper
                      counsel
                      smartparens
		      slime
                      ;; --- Major Mode ---
                      js2-mode
                      ;; --- Minor Mode ---
                      nodejs-repl
                      exec-path-from-shell
                      ;; --- Themes ---
                      monokai-theme
                      ;; solarized-theme
                      ) "Default packages")
(setq package-selected-packages my/packages)
(defun my/packages-installed-p ()
  (loop for pkg in my/packages
        when (not (package-installed-p pkg)) do (return nil)
        finally (return t)))

(unless (my/packages-installed-p)
  (message "%s" "Refreshing package database...")
  (package-refresh-contents)
  (dolist (pkg my/packages)
    (when (not (package-installed-p pkg))
      (package-install pkg))))

;; 开启全局 Company 补全
(global-company-mode 1)


;; Emacs 提供的默认 JavaScript Major Mode 并不是非常好用。所以我们可以将默认的模式 替换成 js2-mode 一个比默认模式好用的 Major Mode。
;;(setq auto-mode-alist
;;      (append
;;       '(("\\.js\\'" . js2-mode))
;;       auto-mode-alist))


;; Set your lisp system and, optionally, some contribs
(setq inferior-lisp-program "d:/dev/sbcl/sbcl.exe")
(require 'slime) 
(setq slime-contribs '(slime-fancy))
(provide 'init-elpa)
```