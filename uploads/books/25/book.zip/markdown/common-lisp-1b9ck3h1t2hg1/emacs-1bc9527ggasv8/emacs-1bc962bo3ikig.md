```
;; 加载主题
(load-theme 'monokai 1)

;; 标题栏显示buffer的名字
(setq frame-title-format "%b")

(provide 'init-ui)
```