# 简介
官方：Gnu Emacs

其它定制版： spacemacs


# 下载



http://www.gnu.org/software/emacs/download.html


[26.2 下载](http://ftp.gnu.org/gnu/emacs/windows/emacs-26/emacs-26.2-x86_64.zip "26.2 下载")


# 安装
解压

## linux
```
./configure --prefix=/usr/local --with-x-toolkit=gtk   --without-x
make && make install
```

# 启动
双击 runemacs.exe

在控制台里:
输入emacs -nw，以终端模式来运行emacs；
只输入emacs，以GUI模式来运行

运行bin目录下的addpm.exe，即可将向开始菜单添加GNU Emacs启动项。