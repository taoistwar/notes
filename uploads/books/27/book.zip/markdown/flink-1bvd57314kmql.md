![](http://socsight.com/uploads/202003/flink/attach_15fda539777e7835.png)

Flink本身也是分层思想的一个实践。

## 部署层
在具体的部署环境（Yarn、K8s）中执行JobGraph。

## 内核层（Runtime）
接入一个JobGraph


## API层
DataStream API 和 DataSet API编译生成JobGraph。

数据集API使用优化器来确定程序的最佳计划
数据流API使用流生成器。

## 类库层
生成API层的程序。


StreamGraph -> JobGraph -> ExecutionGraph