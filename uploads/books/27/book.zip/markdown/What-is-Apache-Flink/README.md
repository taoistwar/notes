## 架构模型


## 任务调度

1. StreamGraph
1. JobGraph
1. ExecutionGraph (由JobManager生成)

## 容错机制

## 组件栈