## SAAS CID状态变化

- 2019-12-19 23:59:53.993	saas_core	148903334	10100	cid状态切换	to=Finished
- 2019-12-19 23:59:53.977	saas_core	148903334	10100	cid状态切换	to=InstanceReleaseing
- 2019-12-19 23:58:56.867	saas_core	148903334	10100	cid状态切换	to=InService
- 2019-12-19 23:58:42.144	saas_core	148903334	10100	cid状态切换	to=InstanceApplying
- 2019-12-19 23:58:41.523	saas_core	148903334	10100	cid状态切换	to=Preparing

## PAAS 实例状态
- paas_edge	148903334	2002	实例状态变化 WORKING


## 开始
### 主要标志
- saas_core	148903334	10100	cid状态切换 
- saas_auth	148903334	100122	申请云玩成功
- saas_core	148903334	10060	SaaS发起申请实例的请求(第一次申请)
- saas_client	148903334	12034	视频流连接成功	
- saas_client	148903334	12045	获取到视频第一帧
### 其它


- saas_core	148183703	10100	cid状态切换	from=PhonePending	to=PhoneRunning	event=PhoneConnect
- saas_client	148183703	12044	流地址获取成功


- saas_client	148183703	12045	获取到视频第一帧

- saas_client	148183703	12041	播流App进入到后台


- paas_edge	148183703	2058	建立流连接
- paas_edge	148183703	2050	实例健康信息

### 池化
- saas_auth	148903334	100132	本次cid属于非池化申请

## 结束
### 正常退出
- 2019-12-19 23:59:53.685	saas_core	148903334	10034	用户云玩时间值
- 2019-12-19 23:59:53.666	saas_core	148903334	10089	SaaS因端主动退出，释放实例

### 异常退出

// TODO 确认
- saas_core	148183703	10091	用户心跳websocket超时