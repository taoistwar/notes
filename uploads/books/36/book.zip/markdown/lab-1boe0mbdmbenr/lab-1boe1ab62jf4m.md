# saas client

## 	调用connect成功 (from saas core 10100)

| event  | from  | to  |
| ------------ | ------------ | ------------ |
| 10100 |PhoneConnect  |PhonePending   |  PhoneRunning |
| 10100 |PhoneDisconnect   |PhoneRunning   | PhonePending  |


## 启动云游戏
| event  | from  | to  | 描述 |
| ------------ | ------------ | ------------ |
| 10012 |  |   | 启动云游戏  |

## 用户心跳websocke

| event  | from  | to  | 描述 |
| ------------ | ------------ | ------------ |
| 10091 |  |   | 超时  |

## 用户断开

| event  | from  | to  | 描述 |
| ------------ | ------------ | ------------ |
| 100669 |  |   | 用户断开  |