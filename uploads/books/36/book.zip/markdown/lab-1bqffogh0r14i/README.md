## [Beam 编程模型](https://beam.apache.org/documentation/programming-guide/ "Beam 编程模型")

### WWWH 
https://www.oreilly.com/ideas/the-world-beyond-batch-streaming-102

## [Beam JAVA API Reference](https://beam.apache.org/releases/javadoc/ "Beam JAVA API Reference")