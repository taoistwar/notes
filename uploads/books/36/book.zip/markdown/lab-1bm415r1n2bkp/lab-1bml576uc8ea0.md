BID下 CID数量，CID去重数。



count: cid

count distinct: user_id