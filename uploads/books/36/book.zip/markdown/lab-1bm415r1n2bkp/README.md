参考：
- 百度 图说 https://tushuo.baidu.com/wave/index#/gallery
- https://chartcube.alipay.com
- https://blog.csdn.net/meng2019/article/details/83624994
- https://www.canva.com/zh_cn/graphs/