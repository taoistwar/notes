```
{
	"path": "/s/ss/cloud-platform-paas-center-controller-log/",
	"serde": {
		"type": "csv"
	}
}
```

+ 根据时间生成path
+ 字段列表