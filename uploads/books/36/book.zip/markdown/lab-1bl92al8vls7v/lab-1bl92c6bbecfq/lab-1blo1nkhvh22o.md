```
{
	"topic": "cloud-platform-paas-center-controller-log",
	"serde": {
		"type": "csv"
	}
}
```