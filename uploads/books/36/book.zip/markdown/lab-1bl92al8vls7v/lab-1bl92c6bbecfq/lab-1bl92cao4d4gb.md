es storage 样例
```
export interface EsStroageConfig {
    esIndex: {
        type: string;
        value: string;
        field: string;
        format: string;
    }
    esType: {
        value: string;
    };
    serde: {
        type: string;
    };
    standalone: {
        type: false,
        condition: {
            operator: string
            field: string
            value: string
        }
    };
}


```

```
{
	"esIndex": {
		"type": "date",
		"value": "cloud_platform_r_*",
		"field": "occur_time",
		"format": "yyyyMMdd"
	},
	"esType": {
		"type": "static",
		"value": "data"
	},
	"serde": {
		"type": "none"
	},
	"standalone": {
	     "type": false,
	     "condition": {
	     	"operator": "=",
	     	"field": "log_type",
	     	"value": "saas_core"
	     }
	}
}
```