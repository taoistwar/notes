es component样例
```
export interface EsComponentConfig {
    address: string[]; // eg. "mvp-hadoop41:9200"
    auth: boolean;
    username: string;
    password: string;
}
```

```
{
	"address": ["mvp-hadoop41:9200"],
	"auth": true,
	"username": "elastic",
	"password": "elastic"
}
```