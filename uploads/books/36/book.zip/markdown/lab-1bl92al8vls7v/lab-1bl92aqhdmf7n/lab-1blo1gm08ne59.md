## HA
```
"config": {
    "type": "ha",
    "namespace": "xx",
    "address": [
        {
            "host": "172.16.209.7",
            "port": 9200
        },
        {
            "host": "172.16.209.9",
            "port": 9200
        }
    ],
    "properties": {
        
    }
}
```

## 无HA
```
"config": {
    "address": {
		"host": "172.16.209.7",
		"port": 9200
	},
    "properties": {
        
    }
}
```