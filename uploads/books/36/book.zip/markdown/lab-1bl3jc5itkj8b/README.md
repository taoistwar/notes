## 技术栈
### 后端
+ Nodejs
+ [Typescript](https://www.tslang.cn/docs/handbook/basic-types.html "Typescript")
+ Graphql ([Apollo实现](https://www.apollographql.com/docs/apollo-server/ "Apollo手册"))

### 前端
+ Angular 8
+ Typescript
+ Graphql client（[Apollo Client](https://www.apollographql.com/docs/angular/ "Apollo Client")）

### 微服务
+ ElasticSearch 查询服务
+ Hive 查询服务
+ Beam Job 管理服务


## 资料
#### EsLint
- https://javascriptplayground.com/typescript-eslint/
- https://prettier.io/docs/en/integrating-with-linters.html
- https://www.robertcooper.me/using-eslint-and-prettier-in-a-typescript-project
- https://prettier.io/docs/en/index.html
- https://www.wisdomgeek.com/development/web-development/how-to-setup-eslint-for-typescript-code/
- https://ts.xcatliu.com/engineering/lint

### TypeScript
- https://ts.xcatliu.com/
-