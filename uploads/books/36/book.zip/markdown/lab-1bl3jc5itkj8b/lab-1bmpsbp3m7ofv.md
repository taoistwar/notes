对TypeScript做代码检查

##  安装依赖
### 源码
```
yarn add --dev eslint typescript prettier @typescript-eslint/eslint-plugin @typescript-eslint/parser eslint-config-prettier eslint-plugin-prettier
```

### IDE (vsCode)
- 安装插件 Prettier
- .vscode/settings.json
```
{
    "git.ignoreLimitWarning": true,
    "cSpell.words": ["eqeqeq", "parens", "proto", "quotemark"],
    "files.eol": "\n",
    "editor.tabSize": 4,
    "editor.defaultFormatter": "esbenp.prettier-vscode",
    "typescript.tsdk": "node_modules/typescript/lib",
    "eslint.autoFixOnSave": true,
    "eslint.validate": [
        "javascript",
        "javascriptreact",
        { "language": "typescript", "autoFix": true },
        { "language": "typescriptreact", "autoFix": true }
    ],
    "editor.formatOnSave": true,
    "[javascript]": {
        "editor.formatOnSave": false
    },
    "[javascriptreact]": {
        "editor.formatOnSave": false
    },
    "[typescript]": {
        "editor.formatOnSave": false
    },
    "[typescriptreact]": {
        "editor.formatOnSave": false
    }
}
```


## 配置文件
`.eslintrc.json`

```
{
    "env": {
        "node": true
    },
    "parser": "@typescript-eslint/parser",
    "parserOptions": {
        // Allows for the parsing of modern ECMAScript features
        "ecmaVersion": 2018,
        // Allows for the use of imports
        "sourceType": "module"
    },
    "extends": [
        // 使用插件@typescript-eslint/eslint-plugin的推荐规则
        "plugin:@typescript-eslint/recommended",
        // 使用eslint-config-prettier来禁用插件@typescript-eslint/eslint-plugin和 prettier 冲突的规则。
        "prettier/@typescript-eslint",
        // 启用 eslint-plugin-prettier 和 eslint-config-prettier.
        // This will display prettier errors as ESLint errors.
        // 确认此配置是 extends 的最后一项
        "plugin:prettier/recommended"
    ],
    "plugins": ["@typescript-eslint"],
    "rules": {
        "prettier": true
    }
}


```


## 执行检查
在`package.json`文件的`scripts`下添加：
```
"lint": "tsc --noEmit && eslint '*/**/*.{js,ts,tsx}' --quiet --fix"
```
执行：
```
npm run lint
或
yarn lint
```