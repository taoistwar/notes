URI:
api/query/1

返回值：
```
{
    "status": "200",
    "data": [
            {
                "title": "My first blog entry",
                "text": "I am starting to get the hang of this...",
                "date": "2018/10/20"
            }
        ]

}
```