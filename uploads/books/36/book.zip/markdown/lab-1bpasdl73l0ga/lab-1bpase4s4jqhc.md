## sub_system_short_name
```
{
  "key" : "PaaS",
  "doc_count" : 356812914
},
{
  "key" : "SaaS",
  "doc_count" : 126550854
}
```
## 微服务
```
{
  "key" : "Controller",
  "doc_count" : 327684362
},
{
  "key" : "ServiceCore",
  "doc_count" : 125871883
},
{
  "key" : "CenterController",
  "doc_count" : 29128552
},
{
  "key" : "DbMonitor",
  "doc_count" : 678971
}
```

## ROM 类型
```
{
  "key" : "RK3288",
  "doc_count" : 15999
},
{
  "key" : "MT8693",
  "doc_count" : 7745
}
```

## method
- applyInstance
- queryInstance
- uninstallWithNfs
- applyInstanceWithAppInstalled
- applyInstanceWithCache
- applyInstanceWithNfs
- checkInstanceRAM
- installWithNfs
- instanceInit
- updateInstanceStatus
- releaseInstance



## Controller
- startAsyncInstancePreparation
- 300203012

|   |   |
| ------------ | ------------ |
| mcro_server_name	| Controller
| method	| startAsyncInstancePreparation
| instanceIp	| 10.177.68.111
| instanceType	| RK3288
| namespace	| migu-rel
| packageName	| com.m37.dldl.aligames