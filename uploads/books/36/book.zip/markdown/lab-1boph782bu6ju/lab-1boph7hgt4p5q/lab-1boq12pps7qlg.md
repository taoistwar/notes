## 维度转换
- 层级维转为通用维


## 行列互转




##　列转行 （宽表）
用来生成宽表，将多行数据根据ID分组后，生成一行。
![](http://socsight.com/uploads/201912/lab/attach_15e342c6c0c52f36.png)

例如, 学生各科目成绩，转换成统一成绩（宽表）

| ID  |name   | course  |score   |
| ------------ | ------------ | ------------ | ------------ |
| 1  |  小明 | 语文  | 95  |
| 1  |  小明 | 数学  | 96  |
| 1  |  小明 | 英语  | 99  |

列转行： 根据ID分组，将course=语文 转为 score_chinese。 score_chinese字段值为score.

| ID  |name   | score_chinese  |score_math   | score_english  |
| ------------ | ------------ | ------------ | ------------ | ------------ |
| 1  |  小明 | 95  | 96  |  99 |

## 行转列
转宽表数据转为多条数据。
![](http://socsight.com/uploads/201912/lab/attach_15e3428a2898fcc0.png)

例如, 学生成绩宽表，转换为原始表

| ID  |name   | score_chinese  |score_math   | score_english  |
| ------------ | ------------ | ------------ | ------------ | ------------ |
| 1  |  小明 | 95  | 96  |  99 |

行转列：字段score_chinese名转为 course=语文，字段score_chinese值转为字段score。

| ID  |name   | course  |score   |
| ------------ | ------------ | ------------ | ------------ |
| 1  |  小明 | 语文  | 95  |
| 1  |  小明 | 数学  | 96  |
| 1  |  小明 | 英语  | 99  |

## 列转多行
字段拆分为数组后，转多行。