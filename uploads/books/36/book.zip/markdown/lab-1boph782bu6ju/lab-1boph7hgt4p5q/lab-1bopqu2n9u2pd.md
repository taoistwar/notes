参考:
- [ABI](http://abidemo.esensoft.com/abi/eportal/pcportal/portal.do?filepath=/root/products/eportal/pcportal/pages/esp/TYMH1/page2.esp "ABI")


## 记录
- 字段长度
- 字段大小
- 字段字节数
- 记录去重： 保留最先/后

## 字段
### 脱敏
- 固定值替换
![](http://socsight.com/uploads/201912/lab/attach_15e33f070b189cbd.png)
- 前后缀增补
- 数据模糊化
![](http://socsight.com/uploads/201912/lab/attach_15e33f1d7fd8a60d.png)
- 数据裁切
- MD5处理
- 哈希处理
- 随机填充
- 偏移值加密


### 字段操作
- 分隔符拆分
  - 特定位置
![](http://socsight.com/uploads/201912/lab/attach_15e33b6e5a61bf9e.png)
  - 任意位置
  ![](http://socsight.com/uploads/201912/lab/attach_15e33b76723ac96a.png)![](http://socsight.com/uploads/201912/lab/attach_15e33b767b03067f.png)
- 前后分隔符提取
![](http://socsight.com/uploads/201912/lab/attach_15e33b62375fe76e.png)
- 字段合并
![](http://socsight.com/uploads/201912/lab/attach_15e33b59dc38e554.png)
- 删除字段
- 智能匹配： 两个字段是否匹配
![](http://socsight.com/uploads/201912/lab/attach_15e33b4954c9aa43.png)

### 字段内容
- 唯一标识
GUID
- 序号

- 字符串填充
  将某一字段使用指定字符串填充到一定长度,补齐操作在原字段上进行。
  如：字符串“1”填充“00”成为“001”，和条件表达式一起完成复杂逻辑。
![](http://socsight.com/uploads/201912/lab/attach_15e33bc9d1ae2918.png)
  - 从前填充
  - 从后填充

- 字符串替换
![](http://socsight.com/uploads/201912/lab/attach_15e33beb40714a1c.png)

- 指定位置添加字符串
![](http://socsight.com/uploads/201912/lab/attach_15e33c05043f5247.png)

- 指定子串前后添加字符串
  在某一字段或所有字段的指定子字符串的前后添加内容,添加操作在原字段上进行。
![](http://socsight.com/uploads/201912/lab/attach_15e33c3e39ddde50.png)

- 删除字符串前后字符
  删除某一字段或所有字段上指定子字符串前后的若干字符,删除操作在原字段上进行。
![](http://socsight.com/uploads/201912/lab/attach_15e33c484a791425.png)

- 删除指定数目的字符
  删除某一字段或所有字段上指定位置的若干字符,删除操作在原字段上进行。
![](http://socsight.com/uploads/201912/lab/attach_15e33c5880058e27.png)

- 删除字符（串）
  删除某一字段或所有字段中包含的指定子字符串,删除操作在原字段上进行。
![](http://socsight.com/uploads/201912/lab/attach_15e33c68ebd8df5d.png)

- 删除空格
  删除空白字符。
![](http://socsight.com/uploads/201912/lab/attach_15e33c76ca795a07.png)

- 舍位
  字段除以指定数值进行舍位，并保留指定的小数位数。
  ![](http://socsight.com/uploads/201912/lab/attach_15e33e233ff6f9ce.png)
### 空值替换
- 指定值替换为NULL
  被选择的字段若等于指定的值,该字段被替换为NULL。
![](http://socsight.com/uploads/201912/lab/attach_15e33e48b83370dc.png)
- NULL替换为指定值
  ![](http://socsight.com/uploads/201912/lab/attach_15e33e595c6af684.png)

### 中文数字处理
- 身份证位数转换
  身份证位数转换（15位转换18位，18位转换15位）。

- 阿拉伯中文数字转换
  阿拉伯数字与汉字相互转换。
  ![](http://socsight.com/uploads/201912/lab/attach_15e33e82667e3002.png)

- 全角半角转换
  所选字段的全角半角相互转换。

### 时间转换
![](http://socsight.com/uploads/201912/lab/attach_15e33ece3bbb8f50.png)

- 日期时间字符串格式转换
- 日期字符串格式转换
- 时间字符串格式转换
- 字符串转换为日期
- 时间戳转换为字符串
- 时间戳字段转换为字符串。