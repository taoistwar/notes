## crontab
![](http://socsight.com/uploads/201912/lab/attach_15e3483d57626737.png)

## 事件驱动