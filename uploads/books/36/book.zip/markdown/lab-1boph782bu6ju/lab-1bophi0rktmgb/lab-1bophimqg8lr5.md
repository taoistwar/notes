## 定义
```
ROWNUMBER(F1, F2, [F3])
```
根据F1分组，在分组内部根据F2排序，返回每组内部排序后的顺序编号（组内连续且唯一）注：MySQL下不支持此函数。
## 参数
参数名	注释	说明
F1	分组字段，可以为NULL，可以为多个（多个字段时为数组形式）	无
F2	排序字段，可以为NULL，也可以为多个（多个字段时为数组形式）	无
F3	排序方向，可选参数，0表示升序，1表示降序；如果指定，那么数组的元素个数必须与F2参数数组元素个数相等	无
## 示例
```SQL
ROWNUMBER(NULL,TableSource1.G166)
ROWNUMBER([TableSource1.COL1,TableSource1.COL2],TableSource1.COL3)
ROWNUMBER(NULL,[TableSource1.COL1,TableSource1.COL2],[1,1])
```