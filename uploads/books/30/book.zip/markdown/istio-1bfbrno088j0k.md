## 架构
+ Istio注入之前的微服务架构
![](http://socsight.com/uploads/201908/istio/attach_15bd7b45f7a10d20.png)

+ Istio注入之后
![](http://socsight.com/uploads/201908/istio/attach_15bd7b61c3fd7470.png)

注意： Reviews服务有3个版本：v1、v2、v3


## 前置条件
#### 开启自动注入sidecar
```
kubectl label namespace default istio-injection=enabled --overwrite
```
#### 进入Istio目录
```
cd istio-1.2.4/
```

## 部署bookinfo
####安装bookinfo
+ 自动注入安装
```
kubectl apply -f samples/bookinfo/platform/kube/bookinfo.yaml
```

+ 手动注入安装
```
kubectl apply -f <(istioctl kube-inject -f samples/bookinfo/platform/kube/bookinfo.yaml)
```
注：为命名空间打上标签 istio-injection=enabled 开启自动注入。前置条件中已经开启

#### 查看pods:
确认所有的 Pod 都已经正确的定义和启动

+ 查看
```
kubectl get pods
```

+ 结果
```
NAME                                                            READY   STATUS    RESTARTS   AGE
details-v1-74f858558f-jzcmt                                     2/2     Running   0          6m7s
productpage-v1-8554d58bff-sqwbt                                 2/2     Running   0          6m3s
ratings-v1-7855f5bcb9-f7h4g                                     2/2     Running   0          6m7s
reviews-v1-59fd8b965b-mpbpk                                     2/2     Running   0          6m6s
reviews-v2-d6cfdb7d6-7v765                                      2/2     Running   0          6m5s
reviews-v3-75699b5cfb-7s77q                                     2/2     Running   0          6m5s
```

#### 查看svc
确认所有的服务都已经正确的定义和启动

+ 查看
```
kubectl get svc
```

+ 结果
```
NAME                                              TYPE           CLUSTER-IP       EXTERNAL-IP   PORT(S)                      AGE
details                                           ClusterIP      10.97.165.88     <none>        9080/TCP                     11m
kubernetes                                        ClusterIP      10.96.0.1        <none>        443/TCP                      7d2h
productpage                                       ClusterIP      10.103.96.38     <none>        9080/TCP                     11m
ratings                                           ClusterIP      10.109.224.231   <none>        9080/TCP                     11m
reviews                                           ClusterIP      10.96.100.147    <none>        9080/TCP                     11m
```

## 配置入口网关
+ 自动注入安装
```
kubectl apply -f samples/bookinfo/networking/bookinfo-gateway.yaml
```

+ 手动注入安装
```
kubectl apply -f <(istioctl kube-inject -f samples/bookinfo/networking/bookinfo-gateway.yaml)
```


#### 查看gateway
+ 查看
```
kubectl get gateway
```

+ 结果
```
NAME               AGE
bookinfo-gateway   4m35s
```

#### 查看virtualservice
+ 查看
```
kubectl get vs
```

+ 结果
```
NAME       GATEWAYS             HOSTS   AGE
bookinfo   [bookinfo-gateway]   [*]     22h
```



#### 
获取端口：
http端口
```
kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].nodePort}'
```
https端口
```
kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}'
```
host：
```
kubectl get pods -l istio=ingressgateway -n istio-system -o wide
```
192.168.219.89：31380

```
export INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].nodePort}')
```