参考：
+ https://istio.io/zh/docs/tasks/traffic-management/ingress/

## 确定ingressgateway入口 IP 和端口


#### 使用外部负载均衡器时确定 IP 和端口
+ IP
```
export INGRESS_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
```

+ http端口
```
export INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].port}')
```

+ https端口
```
export SECURE_INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].port}')
```

请注意，在某些环境中，外部负载均衡器可能需要使用主机名而不是 IP 地址。 在这种情况下，上一节命令输出中的 EXTERNAL-IP 的值就不是 IP 地址， 而是一个主机名，上面的命令将无法设置 INGRESS_HOST 环境变量。在这种情况下，使用以下命令来更正 INGRESS_HOST 值：

```
export INGRESS_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
```

#### 确定使用 Node Port 时的 ingress IP 和端口
如果您确定您的环境没有外部负载均衡器，请按照这些说明操作。

确定端口：
+ http端口
```
export INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].nodePort}')
```
+ https端口
```
export SECURE_INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}')
```