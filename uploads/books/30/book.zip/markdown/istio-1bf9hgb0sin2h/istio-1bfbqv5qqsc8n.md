## 下载

## 安装

https://istio.io/zh/docs/setup/kubernetes/install/kubernetes/


#### 修改istio-ingressgateway服务类型
执行以下命令以确定您的 Kubernetes 集群是否在支持外部负载均衡器的环境中运行。
```
kubectl get svc istio-ingressgateway -n istio-system
```
```
NAME                   TYPE           CLUSTER-IP       EXTERNAL-IP     PORT(S)                                      AGE
istio-ingressgateway   LoadBalancer   172.21.109.129   130.211.10.121  80:31380/TCP,443:31390/TCP,31400:31400/TCP   17h
```

+ 如果 EXTERNAL-IP 有值（IP 地址或主机名），则说明您的环境具有可用于 Ingress 网关的外部负载均衡器。
+ 如果 EXTERNAL-IP 值是 `<none>`（或一直是 `<pending>` ），则说明可能您的环境并没有为 Ingress 网关提供外部负载均衡器的功能。在这种情况下，您可以使用 Service 的 node port 方式访问网关。

#### 修改istio-ingressgateway为NodePort方式
+ 执行如下命令，
编辑服务 `istio-ingressgateway` 将 `spec.type` 的值改为 `NodePort`
```
kubectl patch service istio-ingressgateway -n istio-system -p '{"spec":{"type":"NodePort"}}'
```